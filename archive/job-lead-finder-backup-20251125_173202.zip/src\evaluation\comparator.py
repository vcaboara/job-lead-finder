"""Evaluation comparison and consensus logic."""

import statistics
from typing import Dict

from ..core.abstractions import EvaluationComparator
from ..core.models import JobEvaluation, RelevanceLevel, EvaluationComparison


class SimpleEvaluationComparator(EvaluationComparator):
    """Simple comparator that computes consensus from multiple evaluations."""

    async def compare_evaluations(
        self,
        evaluations: Dict[str, JobEvaluation]
    ) -> EvaluationComparison:
        """
        Compare evaluations from different AI providers.
        
        Args:
            evaluations: Dictionary mapping provider_name -> JobEvaluation
            
        Returns:
            EvaluationComparison with consensus and analysis
        """
        if not evaluations:
            raise ValueError("No evaluations provided")
        
        # Get the first evaluation's job_id (they should all be the same)
        job_id = next(iter(evaluations.values())).job_id
        
        # Calculate consensus score
        scores = [eval_obj.score for eval_obj in evaluations.values()]
        consensus_score = int(statistics.mean(scores))
        
        # Determine consensus relevance level
        relevance_scores = {
            RelevanceLevel.HIGHLY_RELEVANT: 90,
            RelevanceLevel.RELEVANT: 70,
            RelevanceLevel.SOMEWHAT_RELEVANT: 40,
            RelevanceLevel.NOT_RELEVANT: 10,
            RelevanceLevel.UNKNOWN: 0,
        }
        
        weighted_score = sum(
            relevance_scores.get(eval_obj.relevance_level, 0)
            for eval_obj in evaluations.values()
        ) / len(evaluations)
        
        # Map weighted score back to relevance level
        if weighted_score >= 80:
            consensus_relevance = RelevanceLevel.HIGHLY_RELEVANT
        elif weighted_score >= 60:
            consensus_relevance = RelevanceLevel.RELEVANT
        elif weighted_score >= 30:
            consensus_relevance = RelevanceLevel.SOMEWHAT_RELEVANT
        else:
            consensus_relevance = RelevanceLevel.NOT_RELEVANT
        
        # Calculate agreement level
        levels = [eval_obj.relevance_level for eval_obj in evaluations.values()]
        most_common = max(set(levels), key=levels.count)
        agreement_level = levels.count(most_common) / len(levels)
        
        # Generate disagreement analysis
        disagreement_analysis = self._generate_disagreement_analysis(
            evaluations,
            most_common,
            agreement_level
        )
        
        return EvaluationComparison(
            job_id=job_id,
            evaluations=evaluations,
            consensus_relevance=consensus_relevance,
            consensus_score=consensus_score,
            agreement_level=agreement_level,
            disagreement_analysis=disagreement_analysis
        )
    
    def _generate_disagreement_analysis(
        self,
        evaluations: Dict[str, JobEvaluation],
        consensus_level: RelevanceLevel,
        agreement_level: float
    ) -> str:
        """Generate analysis of disagreements between providers."""
        if agreement_level > 0.8:
            return f"Strong consensus: all providers agree on {consensus_level.value}."
        
        # Identify providers with dissenting opinions
        consensus_providers = [
            name for name, eval_obj in evaluations.items()
            if eval_obj.relevance_level == consensus_level
        ]
        dissenting_providers = [
            name for name, eval_obj in evaluations.items()
            if eval_obj.relevance_level != consensus_level
        ]
        
        analysis = f"Moderate consensus ({int(agreement_level * 100)}% agreement): "
        analysis += f"{', '.join(consensus_providers)} agree on {consensus_level.value}, "
        analysis += f"while {', '.join(dissenting_providers)} differ. "
        
        # Explain the disagreement
        if dissenting_providers:
            disagreement_reasons = [
                f"{name}: {evaluations[name].reasoning}"
                for name in dissenting_providers
            ]
            analysis += "Reasons for disagreement: " + "; ".join(disagreement_reasons)
        
        return analysis

#!/usr/bin/env python3
"""
INSTALLATION AND VERIFICATION SCRIPT

Run this to verify the project is set up correctly.
"""

import sys
import subprocess
from pathlib import Path


def check_python_version():
    """Check if Python version is 3.10+"""
    if sys.version_info < (3, 10):
        print(f"❌ Python 3.10+ required. You have {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True


def check_imports():
    """Check if core modules can be imported"""
    try:
        from src.core.models import Job, Resume
        from src.core.abstractions import AIProvider, JobSource
        from src.orchestrator.job_finder import JobFinder
        from src.ai_providers.mock import MockAIProvider
        print("✅ All core imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False


def check_examples():
    """Check if examples can be found"""
    examples = [
        Path("examples/basic_search.py"),
        Path("examples/multi_provider_comparison.py"),
    ]
    
    all_found = True
    for example in examples:
        if example.exists():
            print(f"✅ Found: {example}")
        else:
            print(f"❌ Missing: {example}")
            all_found = False
    
    return all_found


def check_documentation():
    """Check if documentation exists"""
    docs = [
        Path("README.md"),
        Path("ARCHITECTURE.md"),
        Path("QUICKSTART.md"),
        Path("IMPLEMENTATION_SUMMARY.md"),
        Path("SYSTEM_DESIGN.md"),
        Path("FILE_STRUCTURE.md"),
    ]
    
    all_found = True
    for doc in docs:
        if doc.exists():
            print(f"✅ Found: {doc}")
        else:
            print(f"❌ Missing: {doc}")
            all_found = False
    
    return all_found


def main():
    """Run all checks"""
    print("=" * 60)
    print("Job Lead Finder - Installation & Verification")
    print("=" * 60)
    print()
    
    checks = [
        ("Python Version", check_python_version),
        ("Core Imports", check_imports),
        ("Examples", check_examples),
        ("Documentation", check_documentation),
    ]
    
    results = []
    for name, check in checks:
        print(f"\nChecking: {name}")
        print("-" * 60)
        result = check()
        results.append((name, result))
    
    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {name}")
    
    all_passed = all(result for _, result in results)
    
    print("\n" + "=" * 60)
    if all_passed:
        print("✅ All checks passed! Ready to use.")
        print("\nNext steps:")
        print("1. Read QUICKSTART.md for quick introduction")
        print("2. Run: python examples/basic_search.py")
        print("3. Try CLI: job-finder search --help")
        print("4. Review ARCHITECTURE.md for system design")
    else:
        print("❌ Some checks failed. Please fix issues above.")
        return 1
    
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())

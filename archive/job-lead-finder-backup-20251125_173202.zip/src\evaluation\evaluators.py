"""Job evaluation engines."""

import logging
from typing import List, Optional

from ..core.abstractions import JobEvaluator, AIProvider
from ..core.models import Job, JobEvaluation, Resume, JobSearchContext

logger = logging.getLogger(__name__)


class AIProviderEvaluator(JobEvaluator):
    """Evaluates jobs using a specified AI provider."""

    def __init__(self, ai_provider: AIProvider):
        """
        Initialize the evaluator.
        
        Args:
            ai_provider: The AI provider to use for evaluation
        """
        self.ai_provider = ai_provider

    async def evaluate(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """Evaluate a single job."""
        return await self.ai_provider.evaluate_job_relevance(job, resume, context)

    async def batch_evaluate(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """Evaluate multiple jobs."""
        return await self.ai_provider.batch_evaluate_jobs(jobs, resume, context)


class MultiProviderEvaluator(JobEvaluator):
    """Evaluates jobs using multiple AI providers and combines results."""

    def __init__(self, ai_providers: List[AIProvider]):
        """
        Initialize the evaluator.
        
        Args:
            ai_providers: List of AI providers to use
        """
        self.ai_providers = ai_providers

    async def evaluate(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """
        Evaluate a job using all providers and return the consensus.
        
        For multi-provider evaluation, returns a synthesized evaluation.
        """
        evaluations = await self.batch_evaluate([job], resume, context)
        if not evaluations:
            raise ValueError(f"No evaluations returned for job {job.id}")
        return evaluations[0]

    async def batch_evaluate(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """
        Evaluate multiple jobs using all providers.
        
        Returns consensus evaluations from all providers.
        """
        all_evaluations = {}  # job_id -> {provider -> evaluation}
        
        for job in jobs:
            all_evaluations[job.id] = {}
            
            for provider in self.ai_providers:
                try:
                    evaluation = await provider.evaluate_job_relevance(job, resume, context)
                    all_evaluations[job.id][provider.provider_name] = evaluation
                except Exception as e:  # pylint: disable=broad-except
                    logger.error("Error evaluating job %s with provider %s: %s", job.id, provider.provider_name, e)
        
        # Synthesize results - for now, return first provider's evaluation
        # This can be enhanced to combine results intelligently
        result_evaluations = []
        for job in jobs:
            if all_evaluations[job.id]:
                # Use the first successful evaluation (or implement consensus logic)
                first_eval = next(iter(all_evaluations[job.id].values()))
                result_evaluations.append(first_eval)
        
        return result_evaluations

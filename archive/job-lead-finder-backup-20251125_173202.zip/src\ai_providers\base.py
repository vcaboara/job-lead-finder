"""Base class for AI provider implementations."""

import json
import logging
from typing import Any, Dict, List, Optional

from ..core.abstractions import AIProvider
from ..core.models import Job, JobEvaluation, Resume, JobSearchContext, RelevanceLevel

logger = logging.getLogger(__name__)


class BaseAIProvider(AIProvider):
    """Base implementation for AI providers with common functionality."""

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        """
        Initialize the AI provider.
        
        Args:
            api_key: API key for the provider
            model: Model identifier to use
        """
        self.api_key = api_key
        self.model = model

    def _create_evaluation_prompt(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> str:
        """Create a prompt for evaluating job relevance."""
        desired_roles = ", ".join(resume.desired_roles) if resume.desired_roles else "Not specified"
        desired_locations = ", ".join(resume.desired_locations) if resume.desired_locations else "Any"
        skills = ", ".join(resume.skills) if resume.skills else "Not specified"

        prompt = f"""Evaluate the relevance of this job posting to the candidate's profile.

CANDIDATE PROFILE:
- Skills: {skills}
- Experience: {resume.experience}
- Desired Roles: {desired_roles}
- Desired Locations: {desired_locations}

JOB POSTING:
- Title: {job.title}
- Company: {job.company}
- Location: {job.location}
- Job Type: {job.job_type or "Not specified"}
- Description: {job.description}

Provide your evaluation in the following JSON format:
{{
    "relevance_level": "highly_relevant|relevant|somewhat_relevant|not_relevant",
    "score": <0-100>,
    "reasoning": "<brief explanation of relevance>",
    "match_details": {{
        "skills_match": "<how well skills match>",
        "experience_level_match": "<how well experience matches>",
        "location_fit": "<location compatibility>",
        "role_fit": "<how well the role fits desired positions>"
    }}
}}

Be objective and thorough in your assessment."""

        return prompt

    def _create_job_search_prompt(
        self,
        query: str,
        context: Optional[JobSearchContext] = None
    ) -> str:
        """Create a prompt for finding jobs."""
        desired_locations = ", ".join(context.resume.desired_locations) if context and context.resume.desired_locations else "Any"
        desired_roles = ", ".join(context.resume.desired_roles) if context and context.resume.desired_roles else "Any"

        prompt = f"""Search for job opportunities matching these criteria:

SEARCH QUERY: {query}
DESIRED ROLES: {desired_roles}
DESIRED LOCATIONS: {desired_locations}

Note: This is a simulated job search. In a real implementation, you would integrate with job APIs.
For demonstration purposes, provide 3-5 example job listings that would match these criteria.

Return results as JSON array with this structure:
[
    {{
        "title": "<job title>",
        "company": "<company name>",
        "location": "<location>",
        "description": "<job description>",
        "url": "<job url>",
        "job_type": "<full-time|part-time|contract>",
        "salary_range": "<salary if known>"
    }}
]

Only return the JSON array, no additional text."""

        return prompt

    async def _parse_evaluation_response(self, response_text: str) -> Dict[str, Any]:
        """Parse the AI provider's evaluation response."""
        try:
            # Try to extract JSON from the response
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            if start_idx != -1 and end_idx > start_idx:
                json_str = response_text[start_idx:end_idx]
                return json.loads(json_str)
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Failed to parse evaluation response: {e}")
        
        return {
            "relevance_level": "unknown",
            "score": 50,
            "reasoning": "Unable to parse evaluation response",
            "match_details": {}
        }

    def _map_relevance_level(self, level_str: str) -> RelevanceLevel:
        """Map string relevance level to enum."""
        level_str = level_str.lower().strip().replace(" ", "_")
        try:
            return RelevanceLevel[level_str.upper()]
        except KeyError:
            return RelevanceLevel.UNKNOWN

    def _create_comparison_prompt(
        self,
        evaluations: Dict[str, JobEvaluation]
    ) -> str:
        """Create a prompt for comparing multiple evaluations."""
        evaluation_summaries = []
        for provider, eval_obj in evaluations.items():
            evaluation_summaries.append(
                f"- {provider}: {eval_obj.relevance_level.value} (Score: {eval_obj.score}) - {eval_obj.reasoning}"
            )

        prompt = f"""Compare these job relevance evaluations from different AI providers and identify consensus and disagreements:

{chr(10).join(evaluation_summaries)}

Provide analysis in JSON format:
{{
    "consensus_relevance": "highly_relevant|relevant|somewhat_relevant|not_relevant",
    "consensus_score": <0-100>,
    "agreement_level": <0-1>,
    "disagreement_analysis": "<explanation of any major disagreements>"
}}

Only return the JSON object, no additional text."""

        return prompt

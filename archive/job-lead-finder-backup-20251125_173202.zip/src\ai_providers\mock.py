"""Mock AI provider for testing and demonstration."""

import random
from typing import List, Optional

from ..core.models import Job, JobEvaluation, Resume, JobSearchContext, RelevanceLevel
from .base import BaseAIProvider


class MockAIProvider(BaseAIProvider):
    """Mock AI provider for testing without API calls."""

    @property
    def provider_name(self) -> str:
        return "mock"

    async def evaluate_job_relevance(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """Simulate job evaluation with random but realistic results."""
        # Simulate some evaluation logic
        relevance_levels = [
            RelevanceLevel.HIGHLY_RELEVANT,
            RelevanceLevel.RELEVANT,
            RelevanceLevel.SOMEWHAT_RELEVANT,
            RelevanceLevel.NOT_RELEVANT,
        ]
        
        # Slightly bias towards relevance if there are skill matches
        matched_skills = sum(1 for skill in resume.skills if skill.lower() in job.description.lower())
        if matched_skills > len(resume.skills) * 0.5:
            relevance_level = random.choice(relevance_levels[:2])  # Bias towards relevant
        else:
            relevance_level = random.choice(relevance_levels)

        score = random.randint(30, 95) if relevance_level != RelevanceLevel.NOT_RELEVANT else random.randint(10, 40)

        return JobEvaluation(
            job_id=job.id,
            ai_provider=self.provider_name,
            relevance_level=relevance_level,
            score=score,
            reasoning=f"Evaluated based on {matched_skills} skill matches and role fit.",
            match_details={
                "skills_match": f"{matched_skills} of {len(resume.skills)} skills matched",
                "experience_level_match": "Good fit",
                "location_fit": "Perfect match" if job.location in resume.desired_locations else "Possible",
                "role_fit": "Strong" if any(role.lower() in job.title.lower() for role in resume.desired_roles) else "Moderate"
            }
        )

    async def find_jobs(
        self,
        query: str,
        context: Optional[JobSearchContext] = None
    ) -> List[Job]:
        """Generate mock job listings."""
        mock_companies = ["TechCorp", "DataSoft", "CloudServices", "AI Systems", "DevOps Pro"]
        mock_locations = ["San Francisco", "New York", "Remote", "Austin", "Seattle"]
        
        jobs = []
        for i in range(3):
            job = Job(
                id=f"mock_{i}",
                title=f"{query} Engineer - Level {i+1}",
                company=random.choice(mock_companies),
                location=random.choice(mock_locations),
                description=f"We are looking for a {query} professional with strong skills in {', '.join(random.sample(['Python', 'JavaScript', 'Go', 'Rust', 'Java'], 2))}.",
                url=f"https://example.com/jobs/mock_{i}",
                source="mock",
                job_type=random.choice(["full-time", "contract"])
            )
            jobs.append(job)
        
        return jobs

    async def batch_evaluate_jobs(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """Evaluate multiple jobs."""
        evaluations = []
        for job in jobs:
            evaluation = await self.evaluate_job_relevance(job, resume, context)
            evaluations.append(evaluation)
        return evaluations

from typing import List
from .models import Job


class MockJobSource:
    """Very small mock job source returning a handful of jobs."""

    def __init__(self):
        self.source_name = "mock_jobs"

    def search_jobs(self, query: str, limit: int = 5) -> List[Job]:
        base = [
            {
                "id": "1",
                "title": "Senior Python Developer",
                "company": "TechCorp",
                "location": "Remote",
                "description": "Python, Django, Docker, AWS",
                "url": "https://example.com/jobs/1",
            },
            {
                "id": "2",
                "title": "DevOps Engineer",
                "company": "CloudServices",
                "location": "Austin, TX",
                "description": "Kubernetes, Terraform, AWS, CI/CD",
                "url": "https://example.com/jobs/2",
            },
            {
                "id": "3",
                "title": "Junior Backend Developer",
                "company": "StartupXYZ",
                "location": "New York, NY",
                "description": "Node.js, TypeScript, PostgreSQL",
                "url": "https://example.com/jobs/3",
            },
        ]

        results = []
        for item in base:
            if query.lower() in item["title"].lower() or query.lower() in item["description"].lower():
                results.append(Job(**{**item, "source": self.source_name}))
                if len(results) >= limit:
                    break

        # If nothing matched, return first N
        if not results:
            for item in base[:limit]:
                results.append(Job(**{**item, "source": self.source_name}))
        return results

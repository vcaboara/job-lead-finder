"""Abstract base classes defining the core interfaces."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

# Import from same package
from .models import Job, JobEvaluation, Resume, JobSearchContext


class AIProvider(ABC):
    """Abstract base class for AI providers."""

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Name of the AI provider (e.g., 'openai', 'anthropic', 'gemini')."""
        ...

    @abstractmethod
    async def evaluate_job_relevance(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """
        Evaluate how relevant a job is to the user's resume/context.
        
        Args:
            job: The job to evaluate
            resume: User's resume/profile
            context: Additional search context
            
        Returns:
            JobEvaluation with relevance assessment
        """
        ...

    @abstractmethod
    async def find_jobs(
        self,
        query: str,
        context: Optional[JobSearchContext] = None
    ) -> List[Job]:
        """
        Find jobs matching the query using the AI provider.
        
        Args:
            query: Job search query
            context: Additional search context
            
        Returns:
            List of Job objects
        """
        ...

    @abstractmethod
    async def batch_evaluate_jobs(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """
        Evaluate multiple jobs for relevance.
        
        Args:
            jobs: List of jobs to evaluate
            resume: User's resume/profile
            context: Additional search context
            
        Returns:
            List of JobEvaluation objects
        """
        ...

    async def health_check(self) -> bool:
        """Check if the AI provider is accessible and working."""
        return True

    async def get_usage_info(self) -> Dict[str, Any]:
        """Get information about API usage, rate limits, etc."""
        return {}


class JobSource(ABC):
    """Abstract base class for job sources."""

    @property
    @abstractmethod
    def source_name(self) -> str:
        """Name of the job source (e.g., 'linkedin', 'indeed', 'glassdoor')."""
        ...

    @abstractmethod
    async def search_jobs(
        self,
        query: str,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[Job]:
        """
        Search for jobs matching query with optional filters.
        
        Args:
            query: Job search query
            filters: Dictionary of filters (location, job_type, salary_range, etc.)
            
        Returns:
            List of Job objects
        """
        ...

    @abstractmethod
    async def get_job_details(self, job_id: str) -> Optional[Job]:
        """Get detailed information about a specific job."""
        ...

    async def health_check(self) -> bool:
        """Check if the job source is accessible."""
        return True


class JobEvaluator(ABC):
    """Abstract base class for job evaluation engines."""

    @abstractmethod
    async def evaluate(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """Evaluate a single job."""
        ...

    @abstractmethod
    async def batch_evaluate(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """Evaluate multiple jobs."""
        ...


class EvaluationComparator(ABC):
    """Abstract base class for comparing evaluations from multiple providers."""

    @abstractmethod
    async def compare_evaluations(
        self,
        evaluations: Dict[str, JobEvaluation]
    ):
        """
        Compare evaluations from different AI providers.
        
        Args:
            evaluations: Dictionary mapping provider_name -> JobEvaluation
            
        Returns:
            Comparison result with consensus, agreement level, etc.
        """
        ...

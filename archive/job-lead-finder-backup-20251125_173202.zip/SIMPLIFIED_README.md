Simplified Job Lead Finder

This is a compact single-package implementation for quick experiments.

Files:
- `simple_job_finder/` — package with minimal models, sources, providers, and CLI

Quick run (from repository root):

PowerShell:
```powershell
python -m simple_job_finder.main search --query "devops engineer" --skills Python Docker --roles DevOps
```

Notes:
- `gemini` provider is a template placeholder; to enable real Gemini integration install `google-generativeai` and implement API calls.
- This simplified package is intentionally small so you can iterate quickly.

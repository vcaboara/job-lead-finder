"""Core data models for the job finder system."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Any, Dict
from uuid import uuid4


class RelevanceLevel(Enum):
    """Enumeration of job relevance levels."""
    HIGHLY_RELEVANT = "highly_relevant"
    RELEVANT = "relevant"
    SOMEWHAT_RELEVANT = "somewhat_relevant"
    NOT_RELEVANT = "not_relevant"
    UNKNOWN = "unknown"


@dataclass
class Job:
    """Represents a job listing."""
    id: str
    title: str
    company: str
    location: str
    description: str
    url: str
    source: str
    posted_date: Optional[datetime] = None
    salary_range: Optional[str] = None
    job_type: Optional[str] = None  # full-time, part-time, contract, etc.
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid4())


@dataclass
class JobEvaluation:
    """Represents the evaluation of a job's relevance."""
    job_id: str
    ai_provider: str
    relevance_level: RelevanceLevel
    score: float  # 0-100
    reasoning: str
    evaluated_at: datetime = field(default_factory=datetime.now)
    match_details: Dict[str, Any] = field(default_factory=dict)  # Skills match, experience level, etc.


@dataclass
class EvaluationComparison:
    """Represents a comparison of evaluations from multiple AI providers."""
    job_id: str
    evaluations: Dict[str, JobEvaluation]  # provider_name -> evaluation
    consensus_relevance: RelevanceLevel
    consensus_score: float
    agreement_level: float  # 0-1, how much providers agree
    disagreement_analysis: str


@dataclass
class Resume:
    """Represents user's resume/profile context."""
    id: str = field(default_factory=lambda: str(uuid4()))
    content: str = ""
    skills: list[str] = field(default_factory=list)
    experience: str = ""
    desired_roles: list[str] = field(default_factory=list)
    desired_locations: list[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class JobSearchContext:
    """Context for a job search session."""
    resume: Resume
    search_query: str = ""
    preferred_sources: list[str] = field(default_factory=list)
    ai_providers: list[str] = field(default_factory=list)
    filters: Dict[str, Any] = field(default_factory=dict)  # location, salary, job_type, etc.
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class JobFinderResult:
    """Result of a job finding and evaluation operation."""
    jobs: list[Job]
    evaluations: Dict[str, list[JobEvaluation]]  # job_id -> evaluations
    comparisons: Dict[str, EvaluationComparison]  # job_id -> comparison
    search_context: JobSearchContext
    errors: list[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

"""Tests for the main job finder orchestrator."""

import pytest
from src.orchestrator.job_finder import JobFinder
from src.ai_providers.mock import MockAIProvider
from src.job_sources.mock import MockJobSource
from src.evaluation.evaluators import AIProviderEvaluator
from src.evaluation.comparator import SimpleEvaluationComparator
from src.core.models import Resume, JobSearchContext


@pytest.mark.asyncio
async def test_job_finder_initialization():
    """Test job finder initialization."""
    job_finder = JobFinder()
    
    assert len(job_finder.job_sources) == 0
    assert len(job_finder.ai_providers) == 0
    assert len(job_finder.evaluators) == 0


@pytest.mark.asyncio
async def test_register_components():
    """Test registering components."""
    job_finder = JobFinder()
    
    source = MockJobSource()
    provider = MockAIProvider()
    
    job_finder.register_job_source(source)
    job_finder.register_ai_provider(provider)
    job_finder.register_evaluator("mock", AIProviderEvaluator(provider))
    
    assert "mock_jobs" in job_finder.job_sources
    assert "mock" in job_finder.ai_providers
    assert "mock" in job_finder.evaluators


@pytest.mark.asyncio
async def test_find_jobs():
    """Test job finding."""
    job_finder = JobFinder()
    job_finder.register_job_source(MockJobSource())
    
    resume = Resume(skills=["Python"])
    context = JobSearchContext(
        resume=resume,
        search_query="Developer",
        preferred_sources=["mock_jobs"],
    )
    
    jobs = await job_finder.find_jobs(context)
    
    assert len(jobs) > 0
    assert all(job.source == "mock_jobs" for job in jobs)


@pytest.mark.asyncio
async def test_evaluate_jobs():
    """Test job evaluation."""
    job_finder = JobFinder()
    provider = MockAIProvider()
    job_finder.register_ai_provider(provider)
    job_finder.register_evaluator("mock", AIProviderEvaluator(provider))
    
    resume = Resume(skills=["Python", "Docker"])
    context = JobSearchContext(
        resume=resume,
        search_query="Developer",
    )
    
    # Create test jobs
    jobs = await job_finder.find_jobs(context, sources=[])
    jobs_for_eval = await MockJobSource().search_jobs("Developer")
    
    evaluations = await job_finder.evaluate_jobs(
        jobs_for_eval,
        context,
        evaluator_name="mock"
    )
    
    assert len(evaluations) > 0


@pytest.mark.asyncio
async def test_find_and_evaluate_complete_workflow():
    """Test complete find and evaluate workflow."""
    job_finder = JobFinder()
    
    # Register components
    job_finder.register_job_source(MockJobSource())
    provider = MockAIProvider()
    job_finder.register_ai_provider(provider)
    job_finder.register_evaluator("mock", AIProviderEvaluator(provider))
    job_finder.comparator = SimpleEvaluationComparator()
    
    # Create context
    resume = Resume(
        skills=["Python", "Docker", "Kubernetes"],
        desired_roles=["Senior Engineer"],
        desired_locations=["Remote"],
    )
    
    context = JobSearchContext(
        resume=resume,
        search_query="Senior Python Developer",
        preferred_sources=["mock_jobs"],
    )
    
    # Run complete workflow
    result = await job_finder.find_and_evaluate_jobs(context)
    
    assert len(result.jobs) > 0
    assert len(result.evaluations) > 0
    assert result.search_context == context
    assert len(result.errors) == 0


@pytest.mark.asyncio
async def test_health_check():
    """Test health check."""
    job_finder = JobFinder()
    
    job_finder.register_job_source(MockJobSource())
    job_finder.register_ai_provider(MockAIProvider())
    
    health = await job_finder.health_check()
    
    assert health["job_source_mock_jobs"] is True
    assert health["ai_provider_mock"] is True

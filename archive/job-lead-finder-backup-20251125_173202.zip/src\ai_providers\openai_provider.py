"""OpenAI provider implementation (requires openai package)."""

import json
import logging
from typing import List, Optional

from ..core.models import Job, JobEvaluation, Resume, JobSearchContext, RelevanceLevel
from .base import BaseAIProvider

logger = logging.getLogger(__name__)


class OpenAIProvider(BaseAIProvider):
    """AI provider using OpenAI API."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4"):
        """
        Initialize OpenAI provider.
        
        Args:
            api_key: OpenAI API key (uses OPENAI_API_KEY env var if not provided)
            model: Model to use (default: gpt-4)
        """
        super().__init__(api_key, model)
        
        try:
            import openai
            self.openai = openai
            if api_key:
                self.openai.api_key = api_key
        except ImportError:
            raise ImportError(
                "OpenAI package not installed. Install with: pip install 'job-lead-finder[openai]'"
            )

    @property
    def provider_name(self) -> str:
        return "openai"

    async def evaluate_job_relevance(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """Evaluate job relevance using OpenAI."""
        prompt = self._create_evaluation_prompt(job, resume, context)
        
        try:
            response = self.openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert recruiter evaluating job relevance. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=500,
            )
            
            response_text = response.choices[0].message.content
            parsed = await self._parse_evaluation_response(response_text)
            
            return JobEvaluation(
                job_id=job.id,
                ai_provider=self.provider_name,
                relevance_level=self._map_relevance_level(parsed.get("relevance_level", "unknown")),
                score=int(parsed.get("score", 50)),
                reasoning=parsed.get("reasoning", ""),
                match_details=parsed.get("match_details", {})
            )
        except Exception as e:
            logger.error("OpenAI evaluation error: %s", e)
            raise

    async def find_jobs(
        self,
        query: str,
        context: Optional[JobSearchContext] = None
    ) -> List[Job]:
        """Find jobs using OpenAI (simulated - would need job API integration)."""
        prompt = self._create_job_search_prompt(query, context)
        
        try:
            response = self.openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=2000,
            )
            
            response_text = response.choices[0].message.content
            jobs_data = json.loads(response_text)
            
            jobs = []
            for i, job_data in enumerate(jobs_data):
                job = Job(
                    id=f"openai_{i}",
                    title=job_data.get("title", ""),
                    company=job_data.get("company", ""),
                    location=job_data.get("location", ""),
                    description=job_data.get("description", ""),
                    url=job_data.get("url", ""),
                    source=self.provider_name,
                    job_type=job_data.get("job_type"),
                    salary_range=job_data.get("salary_range"),
                )
                jobs.append(job)
            
            return jobs
        except Exception as e:
            logger.error("OpenAI job search error: %s", e)
            return []

    async def batch_evaluate_jobs(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """Batch evaluate multiple jobs."""
        evaluations = []
        for job in jobs:
            try:
                evaluation = await self.evaluate_job_relevance(job, resume, context)
                evaluations.append(evaluation)
            except Exception as e:
                logger.error("Batch evaluation error for job %s: %s", job.id, e)
        return evaluations

    async def health_check(self) -> bool:
        """Check if OpenAI API is accessible."""
        try:
            # Try a simple API call
            response = self.openai.ChatCompletion.create(
                model=self.model,
                messages=[{"role": "user", "content": "test"}],
                max_tokens=1,
            )
            return response.choices is not None
        except Exception as e:
            logger.warning("OpenAI health check failed: %s", e)
            return False

    async def get_usage_info(self) -> dict:
        """Get OpenAI API usage information."""
        try:
            # Note: This would require proper implementation with billing API
            return {
                "model": self.model,
                "status": "active",
            }
        except Exception as e:
            logger.warning("Could not retrieve usage info: %s", e)
            return {}

# Quick Start Guide

## Installation

### Prerequisites
- Python 3.10+
- pip

### Setup

1. **Clone and navigate to the project:**
```bash
cd job-lead-finder
```

2. **Install in development mode:**
```bash
pip install -e ".[dev]"
```

3. **(Optional) Set up environment variables:**
```bash
cp config/.env.example .env
# Edit .env with your API keys if needed
```

## Running Examples

### Basic Job Search
```bash
python examples/basic_search.py
```

This will:
- Search for jobs using the mock job source
- Evaluate relevance using the mock AI provider
- Display results with relevance scores
- Save results to `examples/results.json`

### Multi-Provider Comparison
```bash
python examples/multi_provider_comparison.py
```

This will:
- Search for jobs
- Evaluate with multiple AI providers
- Compare results and calculate consensus
- Save detailed comparison to `examples/multi_provider_results.json`

## Using the CLI

### Search for jobs
```bash
job-finder search --query "Senior Python Developer" \
  --skills Python Docker AWS \
  --roles "Backend Engineer" "Senior Engineer" \
  --locations Remote "San Francisco"
```

### Save results to file
```bash
job-finder search \
  --query "DevOps Engineer" \
  --output results.json
```

### Check service health
```bash
job-finder health
```

### Get help
```bash
job-finder --help
job-finder search --help
```

## Python API Usage

### Basic Example
```python
import asyncio
from src.core.models import Resume, JobSearchContext
from src.orchestrator.job_finder import JobFinder
from src.ai_providers.mock import MockAIProvider
from src.job_sources.mock import MockJobSource
from src.evaluation.evaluators import AIProviderEvaluator

async def main():
    # Setup components
    job_finder = JobFinder()
    job_finder.register_job_source(MockJobSource())
    
    provider = MockAIProvider()
    job_finder.register_ai_provider(provider)
    job_finder.register_evaluator("mock", AIProviderEvaluator(provider))
    
    # Create profile
    resume = Resume(
        skills=["Python", "Docker", "Kubernetes"],
        desired_roles=["Senior Engineer"],
        desired_locations=["Remote"]
    )
    
    # Search context
    context = JobSearchContext(
        resume=resume,
        search_query="Senior Python Developer"
    )
    
    # Find and evaluate
    result = await job_finder.find_and_evaluate_jobs(context)
    
    # Display results
    for job in result.jobs:
        print(f"{job.title} at {job.company}")
        for eval in result.evaluations.get(job.id, []):
            print(f"  Score: {eval.score}/100")

asyncio.run(main())
```

### Multi-Provider Example
```python
from src.evaluation.evaluators import MultiProviderEvaluator
from src.evaluation.comparator import SimpleEvaluationComparator

# Setup multiple providers
provider1 = MockAIProvider()
provider2 = MockAIProvider()

job_finder.register_ai_provider(provider1)
job_finder.register_ai_provider(provider2)

# Use multi-provider evaluator
job_finder.register_evaluator(
    "multi",
    MultiProviderEvaluator([provider1, provider2])
)

# Set up comparator
job_finder.comparator = SimpleEvaluationComparator()

# Run with comparisons
result = await job_finder.find_and_evaluate_jobs(
    context,
    compare_providers=True
)

# View consensus results
for job_id, comparison in result.comparisons.items():
    print(f"Consensus: {comparison.consensus_relevance.value}")
    print(f"Agreement: {int(comparison.agreement_level * 100)}%")
```

## Project Structure

```
src/
├── core/              # Data models and abstractions
├── ai_providers/      # AI provider implementations
├── job_sources/       # Job board sources
├── evaluation/        # Evaluation engines and comparators
├── orchestrator/      # Main JobFinder orchestrator
└── cli/              # Command-line interface

examples/             # Example scripts
tests/               # Unit and integration tests
config/              # Configuration files
```

## Key Components

### AI Providers
- `MockAIProvider`: For testing (no API key needed)
- `OpenAIProvider`: Uses OpenAI API (requires API key)
- `AnthropicProvider`: Uses Anthropic Claude (requires API key)

### Job Sources
- `MockJobSource`: Predefined test jobs
- (Future) LinkedIn, Indeed, Glassdoor integrations

### Evaluators
- `AIProviderEvaluator`: Uses single AI provider
- `MultiProviderEvaluator`: Uses multiple providers for consensus

## Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_ai_providers.py -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html
```

## Extending the System

### Adding a New AI Provider

1. Create `src/ai_providers/my_provider.py`
2. Inherit from `BaseAIProvider`
3. Implement required methods
4. Register with JobFinder

See ARCHITECTURE.md for detailed instructions.

### Adding a New Job Source

1. Create `src/job_sources/my_source.py`
2. Inherit from `JobSource`
3. Implement search and detail methods
4. Register with JobFinder

## Environment Variables

```bash
# API Keys
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...

# App Settings
DEBUG=False
LOG_LEVEL=INFO
```

## Troubleshooting

### Import Errors
```bash
# Make sure you're in the project directory
cd job-lead-finder

# Reinstall in editable mode
pip install -e .
```

### Module Not Found
```bash
# Add project to PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
```

### API Errors
- Check that API keys are set correctly in `.env`
- Verify API access and rate limits
- Check network connectivity

## Next Steps

1. Review the README.md for full documentation
2. Check ARCHITECTURE.md for system design
3. Explore examples/ for usage patterns
4. Run tests to verify setup
5. Integrate with your AI provider of choice
6. Build a UI on top of the API

## Support

- See README.md for comprehensive documentation
- See ARCHITECTURE.md for technical details
- Check examples/ for usage examples
- Review tests/ for test patterns

Happy job hunting! 🎯

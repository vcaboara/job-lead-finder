"""Core module - data models and abstractions."""

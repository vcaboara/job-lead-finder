# System Architecture Diagram

## High-Level Overview

```
┌────────────────────────────────────────────────────────────────────────┐
│                          USER LAYER                                    │
│         (CLI / Web UI / Desktop UI / Python API)                       │
└─────────────────────────────┬────────────────────────────────────────┘
                              │
┌─────────────────────────────▼────────────────────────────────────────┐
│                      ORCHESTRATOR LAYER                               │
│                       (JobFinder)                                     │
│  - Registers components                                              │
│  - Coordinates workflow                                              │
│  - Manages error handling                                            │
└──────────┬──────────────────────────────────┬──────────────────────┘
           │                                  │
    ┌──────▼───────────┐          ┌──────────▼──────────┐
    │   JOB SOURCES    │          │   AI PROVIDERS      │
    │                  │          │                     │
    │ - MockJobSource  │          │ - MockAIProvider    │
    │ - LinkedIn       │          │ - OpenAIProvider    │
    │ - Indeed         │          │ - AnthropicProvider │
    │ - Glassdoor      │          │ - GeminiProvider    │
    │ - Custom APIs    │          │ - Custom Providers  │
    └─────┬────────────┘          └────────┬────────────┘
          │                               │
          │                    ┌──────────▼──────────┐
          │                    │  EVALUATION ENGINE  │
          │                    │                     │
          │                    │ - Evaluators        │
          │                    │ - Comparators       │
          │                    │ - Consensus Logic   │
          │                    └────────┬────────────┘
          │                            │
          └────────────────┬───────────┘
                           │
        ┌──────────────────▼──────────────────┐
        │        RESULT AGGREGATION           │
        │                                     │
        │ - Jobs with Evaluations             │
        │ - Provider Comparisons              │
        │ - Consensus Rankings                │
        │ - Error Handling                    │
        └─────────────────────────────────────┘
```

## Data Flow: Single Provider

```
┌─────────────────┐
│  User Input     │
│ Query + Resume  │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────┐
│ JobSearchContext            │
│ - search_query              │
│ - resume                    │
│ - filters                   │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ JobFinder.find_jobs()       │◄────────┐
│ - Search job sources        │         │
│ - Return Job[]              │         │
└────────┬────────────────────┘         │
         │                              │
         ▼                              │
┌─────────────────────────────┐         │
│ JobFinder.evaluate_jobs()   │         │
│ - Use AI provider           │         │
│ - Return JobEvaluation[]    │         │
└────────┬────────────────────┘         │
         │                              │
         ▼                              │
┌─────────────────────────────┐         │
│ JobFinderResult             │◄────────┘
│ - jobs: Job[]               │
│ - evaluations:              │
│   {job_id: Eval[]}          │
│ - comparisons: {}           │
│ - errors: []                │
└─────────────────────────────┘
```

## Data Flow: Multi-Provider with Comparison

```
┌─────────────────┐
│  User Input     │
│ Query + Resume  │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────┐
│ JobSearchContext            │
│ (compare_providers=True)    │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ JobFinder.find_jobs()       │
│ - Search all sources        │
│ - Return Job[]              │
└────────┬────────────────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│ JobFinder.evaluate_jobs(all_providers)   │
│                                          │
│  For each job:                           │
│  ├─ Provider 1 ──► JobEvaluation        │
│  ├─ Provider 2 ──► JobEvaluation        │
│  └─ Provider N ──► JobEvaluation        │
│                                          │
└────────┬─────────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│ JobFinder.compare_evaluations()          │
│                                          │
│  For each job:                           │
│  ├─ Calculate consensus                  │
│  ├─ Calculate agreement level            │
│  ├─ Analyze disagreements                │
│  └─ Return EvaluationComparison          │
│                                          │
└────────┬─────────────────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ JobFinderResult             │
│ - jobs: Job[]               │
│ - evaluations:              │
│   {job_id: Eval[]}          │
│ - comparisons:              │
│   {job_id: Comparison}      │
│ - errors: []                │
└─────────────────────────────┘
```

## Component Relationships

```
AIProvider (Abstract)
├── MockAIProvider
├── OpenAIProvider
├── AnthropicProvider
└── GeminiProvider

JobSource (Abstract)
├── MockJobSource
├── LinkedInSource
├── IndeedSource
└── GlassdoorSource

JobEvaluator (Abstract)
├── AIProviderEvaluator
└── MultiProviderEvaluator

EvaluationComparator (Abstract)
└── SimpleEvaluationComparator

JobFinder (Orchestrator)
├── Contains: JobSource[]
├── Contains: AIProvider[]
├── Contains: JobEvaluator[]
├── Contains: EvaluationComparator
└── Methods:
    ├── find_jobs()
    ├── evaluate_jobs()
    ├── compare_evaluations()
    └── find_and_evaluate_jobs()
```

## Workflow States

```
┌─────────────┐
│  INITIAL    │ User provides query & resume
└──────┬──────┘
       │
       ▼
┌─────────────────────────┐
│  SEARCHING FOR JOBS     │ JobFinder queries job sources
└──────┬──────────────────┘
       │
       ▼
┌─────────────────────────┐
│  JOBS FOUND             │ List of jobs retrieved
└──────┬──────────────────┘
       │
       ▼
┌─────────────────────────┐
│  EVALUATING             │ AI providers assess relevance
└──────┬──────────────────┘
       │
       ▼
┌─────────────────────────┐
│  EVALUATIONS COMPLETE   │ Individual scores & reasoning
└──────┬──────────────────┘
       │
       ├─────────────────────────────┐
       │                             │
       ▼ (if compare_providers)      ▼ (else)
┌──────────────────┐        ┌──────────────────┐
│ COMPARING RESULTS│        │  RETURN RESULTS  │
└──────┬───────────┘        └──────────────────┘
       │
       ▼
┌─────────────────────────┐
│  CONSENSUS CALCULATED   │ Agreement levels determined
└──────┬──────────────────┘
       │
       ▼
┌─────────────────────────┐
│  RETURN RESULTS         │ Complete JobFinderResult
└─────────────────────────┘
```

## Error Handling Flow

```
Operation starts
      │
      ▼
Try to execute
      │
      ├─── Success ───► Log & Continue
      │
      └─── Error ──────┐
                       ▼
                 Catch Exception
                       │
                       ├─── Log error
                       ├─── Add to errors list
                       ├─── Graceful degradation
                       └─── Continue if possible
                             │
                             ▼
                    Return partial results
                    with error details
```

## Component Interaction Example

```
User: search("Python Developer", resume)
   │
   ▼
JobFinder.find_and_evaluate_jobs(context)
   │
   ├─► find_jobs()
   │   ├─► MockJobSource.search_jobs()
   │   │   └─► returns [Job1, Job2, Job3]
   │   └─► returns all jobs
   │
   ├─► evaluate_jobs(all_providers=True)
   │   ├─► Provider1.evaluate_job_relevance(Job1, resume)
   │   │   └─► JobEvaluation1
   │   ├─► Provider2.evaluate_job_relevance(Job1, resume)
   │   │   └─► JobEvaluation2
   │   ├─► ... (repeat for all jobs)
   │   └─► returns {job_id: [evaluations]}
   │
   ├─► compare_evaluations()
   │   ├─► for each job, compare all evaluations
   │   ├─► calculate consensus
   │   ├─► calculate agreement level
   │   └─► returns {job_id: EvaluationComparison}
   │
   └─► return JobFinderResult
       ├─ jobs: [Job1, Job2, Job3]
       ├─ evaluations: {
       │    job1: [Eval1, Eval2],
       │    job2: [Eval1, Eval2],
       │    job3: [Eval1, Eval2]
       │  }
       ├─ comparisons: {
       │    job1: Comparison{consensus: RELEVANT, agreement: 95%},
       │    job2: Comparison{consensus: SOMEWHAT_RELEVANT, agreement: 50%},
       │    job3: Comparison{consensus: NOT_RELEVANT, agreement: 100%}
       │  }
       └─ errors: []
```

## Configuration Flow

```
User/System
     │
     ▼
Environment Variables
     │
     ├─ OPENAI_API_KEY
     ├─ ANTHROPIC_API_KEY
     ├─ LOG_LEVEL
     └─ DEBUG
     │
     ▼
AppConfig.from_env()
     │
     ▼
JobFinder.register_providers()
     │
     ├─► OpenAIProvider(api_key)
     ├─► AnthropicProvider(api_key)
     └─► ...
     │
     ▼
Ready to use
```

---

This architecture enables:
- **Modularity**: Easy to add new components
- **Extensibility**: Simple to integrate new providers
- **Scalability**: Concurrent operations with async/await
- **Reliability**: Error handling and graceful degradation
- **Comparison**: Multi-provider consensus calculation

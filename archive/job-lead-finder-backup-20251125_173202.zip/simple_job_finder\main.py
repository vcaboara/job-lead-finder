"""Simplified CLI and orchestrator.

Usage:
  python -m simple_job_finder.main search --query "devops engineer" --skills Python Docker
"""
import argparse
from .sources import MockJobSource
from .providers import MockAIProvider, GeminiProviderTemplate
from .models import Resume


def build_parser():
    p = argparse.ArgumentParser(prog="simple-job-finder")
    sub = p.add_subparsers(dest="cmd")

    search = sub.add_parser("search", help="Search and evaluate jobs")
    search.add_argument("--query", "-q", required=True)
    search.add_argument("--skills", "-s", nargs="*", default=["Python", "Docker"]) 
    search.add_argument("--roles", "-r", nargs="*", default=["Engineer"]) 
    search.add_argument("--locations", "-l", nargs="*", default=["Remote"]) 
    search.add_argument("--provider", "-p", choices=["mock", "gemini"], default="mock")

    health = sub.add_parser("health", help="Check health (mock only)")
    return p


def cmd_search(args):
    resume = Resume(skills=args.skills, desired_roles=args.roles, desired_locations=args.locations)
    source = MockJobSource()
    jobs = source.search_jobs(args.query)

    if args.provider == "mock":
        provider = MockAIProvider()
    else:
        provider = GeminiProviderTemplate()

    results = []
    for job in jobs:
        eval_obj = provider.evaluate(job, resume)
        results.append({
            "id": job.id,
            "title": job.title,
            "company": job.company,
            "location": job.location,
            "score": eval_obj.score,
            "reasoning": eval_obj.reasoning,
            "url": job.url,
        })

    # Print simple JSON-ish output
    for r in results:
        print(f"{r['title']} @ {r['company']} ({r['location']}) — score: {r['score']}")
        print(f"  Reason: {r['reasoning']}")
        print(f"  URL: {r['url']}\n")


def cmd_health(_args):
    print("mock_jobs: ok")
    print("mock_provider: ok")
    print("gemini: template (not active)")


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.cmd == "search":
        cmd_search(args)
    elif args.cmd == "health":
        cmd_health(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

"""Example: Basic Job Search"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.core.models import Resume, JobSearchContext
from src.orchestrator.job_finder import JobFinder
from src.ai_providers.mock import MockAIProvider
from src.job_sources.mock import MockJobSource
from src.evaluation.evaluators import AIProviderEvaluator
import json


async def main():
    """Run a basic job search example."""

    # Setup job finder with components
    job_finder = JobFinder()

    # Register job source
    job_finder.register_job_source(MockJobSource())

    # Register AI provider
    mock_ai = MockAIProvider()
    job_finder.register_ai_provider(mock_ai)

    # Register evaluator
    job_finder.register_evaluator("mock", AIProviderEvaluator(mock_ai))

    # Create resume
    resume = Resume(
        content="""
        Senior Software Engineer with 8+ years of experience.
        Expertise: Python, JavaScript, DevOps, Cloud Architecture
        Experience: Full-stack development, microservices, Kubernetes
        """,
        skills=["Python", "JavaScript", "Docker", "Kubernetes", "AWS", "PostgreSQL"],
        experience="8 years of full-stack and DevOps experience",
        desired_roles=["Senior Engineer", "Staff Engineer", "DevOps Lead"],
        desired_locations=["Remote", "San Francisco", "New York"],
    )

    # Create search context
    context = JobSearchContext(
        resume=resume,
        search_query="Senior Python Developer",
        preferred_sources=["mock_jobs"],
        ai_providers=["mock"],
    )

    # Find and evaluate jobs
    print("🔍 Searching for jobs...")
    result = await job_finder.find_and_evaluate_jobs(
        context=context,
        job_sources=["mock_jobs"],
    )

    # Display results
    print(f"\n📊 Found {len(result.jobs)} jobs")
    print(f"✅ Evaluated {len(result.evaluations)} jobs")

    for job in result.jobs:
        print(f"\n{'=' * 80}")
        print(f"📌 {job.title}")
        print(f"   Company: {job.company}")
        print(f"   Location: {job.location}")
        print(f"   Type: {job.job_type}")
        print(f"   Salary: {job.salary_range}")
        print(f"   URL: {job.url}")

        # Show evaluations
        if job.id in result.evaluations:
            for eval_obj in result.evaluations[job.id]:
                print(
                    f"\n   📈 Evaluation (by {eval_obj.ai_provider}):"
                )
                print(f"      Relevance: {eval_obj.relevance_level.value}")
                print(f"      Score: {eval_obj.score}/100")
                print(f"      Reasoning: {eval_obj.reasoning}")
                if eval_obj.match_details:
                    print("      Match Details:")
                    for key, value in eval_obj.match_details.items():
                        print(f"        - {key}: {value}")

    # Save results to JSON
    output = {
        "summary": {
            "total_jobs_found": len(result.jobs),
            "total_evaluated": len(result.evaluations),
        },
        "jobs": [
            {
                "id": job.id,
                "title": job.title,
                "company": job.company,
                "location": job.location,
                "evaluations": [
                    {
                        "provider": e.ai_provider,
                        "relevance": e.relevance_level.value,
                        "score": e.score,
                        "reasoning": e.reasoning,
                    }
                    for e in result.evaluations.get(job.id, [])
                ],
            }
            for job in result.jobs
        ],
    }

    results_file = Path(__file__).parent / "results.json"
    results_file.write_text(json.dumps(output, indent=2))
    print(f"\n💾 Results saved to {results_file}")


if __name__ == "__main__":
    asyncio.run(main())

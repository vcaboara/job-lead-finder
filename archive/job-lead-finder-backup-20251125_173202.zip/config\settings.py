"""Configuration management for the job finder."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class AIProviderConfig:
    """Configuration for AI providers."""
    provider_type: str  # "openai", "anthropic", "gemini", "mock"
    api_key: Optional[str] = None
    model: Optional[str] = None
    
    def from_env(self, provider_type: str):
        """Load configuration from environment variables."""
        env_key_map = {
            "openai": "OPENAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "gemini": "GOOGLE_API_KEY",
        }
        
        api_key_env = env_key_map.get(provider_type)
        if api_key_env:
            self.api_key = os.getenv(api_key_env)


@dataclass
class JobSourceConfig:
    """Configuration for job sources."""
    source_type: str  # "linkedin", "indeed", "glassdoor", "mock"
    api_key: Optional[str] = None
    base_url: Optional[str] = None


@dataclass
class AppConfig:
    """Application configuration."""
    debug: bool = False
    log_level: str = "INFO"
    ai_providers: list[AIProviderConfig] = field(default_factory=list)
    job_sources: list[JobSourceConfig] = field(default_factory=list)
    
    @classmethod
    def from_env(cls):
        """Load configuration from environment variables."""
        config = cls(
            debug=os.getenv("DEBUG", "False").lower() == "true",
            log_level=os.getenv("LOG_LEVEL", "INFO"),
        )
        return config
    
    @classmethod
    def from_file(cls, config_path: Path):
        """Load configuration from a YAML/JSON file."""
        # This is a template - implement based on your config format
        raise NotImplementedError("Config file loading not yet implemented")


def load_config() -> AppConfig:
    """Load application configuration."""
    config_path = Path(__file__).parent.parent / "config.yaml"
    
    if config_path.exists():
        return AppConfig.from_file(config_path)
    else:
        return AppConfig.from_env()

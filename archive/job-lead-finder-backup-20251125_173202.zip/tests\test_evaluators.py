"""Tests for job evaluators."""

import pytest
from src.evaluation.evaluators import AIProviderEvaluator, MultiProviderEvaluator
from src.ai_providers.mock import MockAIProvider
from src.core.models import Job, Resume


@pytest.mark.asyncio
async def test_ai_provider_evaluator():
    """Test single AI provider evaluator."""
    provider = MockAIProvider()
    evaluator = AIProviderEvaluator(provider)
    
    job = Job(
        id="test_1",
        title="Python Developer",
        company="Tech Corp",
        location="Remote",
        description="Python developer needed",
        url="https://example.com",
        source="test"
    )
    
    resume = Resume(skills=["Python", "Docker"])
    
    evaluation = await evaluator.evaluate(job, resume)
    
    assert evaluation.job_id == job.id
    assert evaluation.ai_provider == "mock"
    assert evaluation.score >= 0


@pytest.mark.asyncio
async def test_batch_evaluation():
    """Test batch job evaluation."""
    provider = MockAIProvider()
    evaluator = AIProviderEvaluator(provider)
    
    jobs = [
        Job(
            id="test_1",
            title="Python Developer",
            company="Corp1",
            location="Remote",
            description="Python skills needed",
            url="https://example.com/1",
            source="test"
        ),
        Job(
            id="test_2",
            title="JavaScript Developer",
            company="Corp2",
            location="SF",
            description="JavaScript skills needed",
            url="https://example.com/2",
            source="test"
        ),
    ]
    
    resume = Resume(skills=["Python", "JavaScript"])
    
    evaluations = await evaluator.batch_evaluate(jobs, resume)
    
    assert len(evaluations) == 2
    assert evaluations[0].job_id == "test_1"
    assert evaluations[1].job_id == "test_2"


@pytest.mark.asyncio
async def test_multi_provider_evaluator():
    """Test multi-provider evaluator."""
    provider1 = MockAIProvider()
    provider2 = MockAIProvider()
    
    evaluator = MultiProviderEvaluator([provider1, provider2])
    
    job = Job(
        id="test_1",
        title="Senior Engineer",
        company="Tech Corp",
        location="Remote",
        description="Senior engineer position",
        url="https://example.com",
        source="test"
    )
    
    resume = Resume(skills=["Python", "AWS", "Kubernetes"])
    
    evaluation = await evaluator.evaluate(job, resume)
    
    assert evaluation.job_id == job.id
    assert evaluation.score >= 0


@pytest.mark.asyncio
async def test_multi_provider_batch_evaluation():
    """Test batch evaluation with multiple providers."""
    providers = [MockAIProvider(), MockAIProvider()]
    evaluator = MultiProviderEvaluator(providers)
    
    jobs = [
        Job(
            id="test_1",
            title="Python Developer",
            company="Corp1",
            location="Remote",
            description="Python skills needed",
            url="https://example.com/1",
            source="test"
        ),
        Job(
            id="test_2",
            title="DevOps Engineer",
            company="Corp2",
            location="SF",
            description="DevOps skills needed",
            url="https://example.com/2",
            source="test"
        ),
    ]
    
    resume = Resume(
        skills=["Python", "Docker", "Kubernetes", "AWS"],
        desired_roles=["Senior Engineer"],
    )
    
    evaluations = await evaluator.batch_evaluate(jobs, resume)
    
    assert len(evaluations) >= 1  # At least some evaluations
    assert all(e.score >= 0 for e in evaluations)

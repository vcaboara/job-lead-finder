"""Simplified Job Finder package (single-file friendly).
"""
__all__ = ["models", "sources", "providers", "main"]

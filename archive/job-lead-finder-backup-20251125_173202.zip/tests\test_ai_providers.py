"""Tests for AI providers."""

import pytest
from src.ai_providers.mock import MockAIProvider
from src.core.models import Job, Resume, JobSearchContext


@pytest.mark.asyncio
async def test_mock_provider_name():
    """Test that mock provider has correct name."""
    provider = MockAIProvider()
    assert provider.provider_name == "mock"


@pytest.mark.asyncio
async def test_mock_evaluate_job_relevance():
    """Test job relevance evaluation."""
    provider = MockAIProvider()
    
    job = Job(
        id="test_1",
        title="Python Developer",
        company="Tech Corp",
        location="Remote",
        description="Looking for Python developer with Django and PostgreSQL experience.",
        url="https://example.com/jobs/1",
        source="test",
        job_type="full-time"
    )
    
    resume = Resume(
        skills=["Python", "Django", "PostgreSQL", "Docker"],
        desired_roles=["Software Engineer"],
        desired_locations=["Remote"],
    )
    
    evaluation = await provider.evaluate_job_relevance(job, resume)
    
    assert evaluation.job_id == job.id
    assert evaluation.ai_provider == "mock"
    assert 0 <= evaluation.score <= 100
    assert evaluation.reasoning
    assert evaluation.relevance_level


@pytest.mark.asyncio
async def test_mock_find_jobs():
    """Test job finding."""
    provider = MockAIProvider()
    
    jobs = await provider.find_jobs("Python Developer")
    
    assert len(jobs) > 0
    assert all(isinstance(job, Job) for job in jobs)
    assert all(job.source == "mock" for job in jobs)


@pytest.mark.asyncio
async def test_mock_batch_evaluate():
    """Test batch evaluation."""
    provider = MockAIProvider()
    
    jobs = [
        Job(
            id="test_1",
            title="Senior Python Developer",
            company="TechCorp",
            location="Remote",
            description="Looking for Python expert",
            url="https://example.com/1",
            source="test"
        ),
        Job(
            id="test_2",
            title="Junior Frontend Developer",
            company="WebCorp",
            location="San Francisco",
            description="Looking for React developer",
            url="https://example.com/2",
            source="test"
        ),
    ]
    
    resume = Resume(
        skills=["Python", "Django", "React"],
        desired_roles=["Senior Developer"],
    )
    
    evaluations = await provider.batch_evaluate_jobs(jobs, resume)
    
    assert len(evaluations) == len(jobs)
    assert all(e.job_id in [j.id for j in jobs] for e in evaluations)


@pytest.mark.asyncio
async def test_mock_health_check():
    """Test health check."""
    provider = MockAIProvider()
    
    is_healthy = await provider.health_check()
    
    assert is_healthy is True


@pytest.mark.asyncio
async def test_evaluation_with_skill_matching():
    """Test that evaluations consider skill matches."""
    provider = MockAIProvider()
    
    # Job requiring specific skills
    job = Job(
        id="test_match",
        title="Python Expert",
        company="TechCorp",
        location="Remote",
        description="Expert Python developer. Required: Python, Kubernetes, AWS.",
        url="https://example.com",
        source="test"
    )
    
    # Resume with matching skills
    resume = Resume(
        skills=["Python", "Kubernetes", "AWS", "Docker"],
        desired_roles=["Senior Developer"],
    )
    
    evaluation = await provider.evaluate_job_relevance(job, resume)
    
    # Should be relevant due to skill matches
    assert evaluation.score > 50
    assert "Python" in evaluation.match_details.get("skills_match", "")

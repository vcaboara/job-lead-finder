"""Main orchestrator for job finding and evaluation."""

import logging
from typing import Dict, List, Optional

from ..core.abstractions import AIProvider, JobSource, JobEvaluator, EvaluationComparator
from ..core.models import Job, JobSearchContext, JobFinderResult, JobEvaluation, EvaluationComparison

logger = logging.getLogger(__name__)


class JobFinder:
    """Main orchestrator that coordinates job finding and evaluation."""

    def __init__(
        self,
        job_sources: Optional[Dict[str, JobSource]] = None,
        ai_providers: Optional[Dict[str, AIProvider]] = None,
        evaluators: Optional[Dict[str, JobEvaluator]] = None,
        comparator: Optional[EvaluationComparator] = None,
    ):
        """
        Initialize the job finder.
        
        Args:
            job_sources: Dictionary of {source_name -> JobSource}
            ai_providers: Dictionary of {provider_name -> AIProvider}
            evaluators: Dictionary of {evaluator_name -> JobEvaluator}
            comparator: Optional comparator for multi-provider evaluation
        """
        self.job_sources = job_sources or {}
        self.ai_providers = ai_providers or {}
        self.evaluators = evaluators or {}
        self.comparator = comparator

    def register_job_source(self, source: JobSource) -> None:
        """Register a new job source."""
        self.job_sources[source.source_name] = source

    def register_ai_provider(self, provider: AIProvider) -> None:
        """Register a new AI provider."""
        self.ai_providers[provider.provider_name] = provider

    def register_evaluator(self, name: str, evaluator: JobEvaluator) -> None:
        """Register a new evaluator."""
        self.evaluators[name] = evaluator

    async def find_jobs(
        self,
        context: JobSearchContext,
        sources: Optional[List[str]] = None,
    ) -> List[Job]:
        """
        Find jobs using specified sources.
        
        Args:
            context: The search context
            sources: List of source names to search (uses all if None)
            
        Returns:
            List of Job objects
        """
        sources_to_use = sources or list(self.job_sources.keys())
        all_jobs = []
        
        for source_name in sources_to_use:
            if source_name not in self.job_sources:
                logger.warning("Job source %s not registered", source_name)
                continue
            
            try:
                source = self.job_sources[source_name]
                jobs = await source.search_jobs(
                    context.search_query,
                    context.filters
                )
                all_jobs.extend(jobs)
                logger.info("Found %d jobs from source %s", len(jobs), source_name)
            except Exception as e:  # pylint: disable=broad-except
                logger.error("Error searching jobs from source %s: %s", source_name, e)
        
        return all_jobs

    async def evaluate_jobs(
        self,
        jobs: List[Job],
        context: JobSearchContext,
        evaluator_name: Optional[str] = None,
        all_providers: bool = False,
    ) -> Dict[str, List[JobEvaluation]]:
        """
        Evaluate jobs using specified evaluator(s).
        
        Args:
            jobs: List of jobs to evaluate
            context: The search context
            evaluator_name: Specific evaluator to use (uses first if None)
            all_providers: If True, evaluate with all AI providers
            
        Returns:
            Dictionary mapping job_id -> list of evaluations
        """
        evaluations_by_job = {}
        
        if not jobs:
            return evaluations_by_job
        
        if all_providers:
            # Evaluate with all available AI providers
            for provider_name, provider in self.ai_providers.items():
                for job in jobs:
                    try:
                        evaluation = await provider.evaluate_job_relevance(
                            job,
                            context.resume,
                            context
                        )
                        if job.id not in evaluations_by_job:
                            evaluations_by_job[job.id] = []
                        evaluations_by_job[job.id].append(evaluation)
                        logger.debug("Evaluated job %s with provider %s", job.id, provider_name)
                    except Exception as e:  # pylint: disable=broad-except
                        logger.error("Error evaluating job %s with provider %s: %s", job.id, provider_name, e)
        else:
            # Evaluate with specified evaluator
            evaluator_to_use = evaluator_name or list(self.evaluators.keys())[0]
            
            if evaluator_to_use not in self.evaluators:
                logger.error("Evaluator %s not registered", evaluator_to_use)
                return evaluations_by_job
            
            try:
                evaluator = self.evaluators[evaluator_to_use]
                evaluations = await evaluator.batch_evaluate(
                    jobs,
                    context.resume,
                    context
                )
                
                for evaluation in evaluations:
                    if evaluation.job_id not in evaluations_by_job:
                        evaluations_by_job[evaluation.job_id] = []
                    evaluations_by_job[evaluation.job_id].append(evaluation)
                    
                logger.info("Evaluated %d jobs with evaluator %s", len(jobs), evaluator_to_use)
            except Exception as e:  # pylint: disable=broad-except
                logger.error("Error batch evaluating jobs: %s", e)
        
        return evaluations_by_job

    async def compare_evaluations(
        self,
        evaluations_by_job: Dict[str, List[JobEvaluation]],
    ) -> Dict[str, EvaluationComparison]:
        """
        Compare evaluations from multiple providers for each job.
        
        Args:
            evaluations_by_job: Dictionary mapping job_id -> list of evaluations
            
        Returns:
            Dictionary mapping job_id -> EvaluationComparison
        """
        comparisons = {}
        
        if not self.comparator:
            logger.warning("No comparator registered, skipping comparison")
            return comparisons
        
        for job_id, evaluations in evaluations_by_job.items():
            if len(evaluations) < 2:
                logger.debug("Skipping comparison for job %s (need multiple evaluations)", job_id)
                continue
            
            # Convert list to dict mapping provider_name -> evaluation
            evaluation_dict = {
                eval_obj.ai_provider: eval_obj
                for eval_obj in evaluations
            }
            
            try:
                comparison = await self.comparator.compare_evaluations(evaluation_dict)
                comparisons[job_id] = comparison
                logger.debug("Compared %d evaluations for job %s", len(evaluations), job_id)
            except Exception as e:  # pylint: disable=broad-except
                logger.error("Error comparing evaluations for job %s: %s", job_id, e)
        
        return comparisons

    async def find_and_evaluate_jobs(
        self,
        context: JobSearchContext,
        job_sources: Optional[List[str]] = None,
        evaluator_name: Optional[str] = None,
        compare_providers: bool = False,
    ) -> JobFinderResult:
        """
        Complete job finding and evaluation workflow.
        
        Args:
            context: The search context
            job_sources: List of job sources to use (uses all if None)
            evaluator_name: Specific evaluator to use
            compare_providers: Whether to compare evaluations from multiple providers
            
        Returns:
            JobFinderResult with all jobs and evaluations
        """
        result = JobFinderResult(
            jobs=[],
            evaluations={},
            comparisons={},
            search_context=context,
            errors=[]
        )
        
        # Find jobs
        try:
            jobs = await self.find_jobs(context, job_sources)
            result.jobs = jobs
            logger.info("Found %d total jobs", len(jobs))
        except Exception as e:  # pylint: disable=broad-except
            logger.error("Error finding jobs: %s", e)
            result.errors.append(f"Error finding jobs: {str(e)}")
            return result
        
        # Evaluate jobs
        try:
            all_providers = compare_providers or (evaluator_name is None and len(self.ai_providers) > 1)
            evaluations = await self.evaluate_jobs(
                jobs,
                context,
                evaluator_name,
                all_providers
            )
            result.evaluations = evaluations
            logger.info("Evaluated %d jobs", len(evaluations))
        except Exception as e:  # pylint: disable=broad-except
            logger.error("Error evaluating jobs: %s", e)
            result.errors.append(f"Error evaluating jobs: {str(e)}")
            return result
        
        # Compare evaluations if requested
        if compare_providers and self.comparator:
            try:
                comparisons = await self.compare_evaluations(evaluations)
                result.comparisons = comparisons
                logger.info("Compared evaluations for %d jobs", len(comparisons))
            except Exception as e:  # pylint: disable=broad-except
                logger.error("Error comparing evaluations: %s", e)
                result.errors.append(f"Error comparing evaluations: {str(e)}")
        
        return result

    async def health_check(self) -> Dict[str, bool]:
        """Check health of all registered sources and providers."""
        health = {}
        
        for name, source in self.job_sources.items():
            try:
                health[f"job_source_{name}"] = await source.health_check()
            except Exception as e:  # pylint: disable=broad-except
                logger.warning("Health check failed for job source %s: %s", name, e)
                health[f"job_source_{name}"] = False
        
        for name, provider in self.ai_providers.items():
            try:
                health[f"ai_provider_{name}"] = await provider.health_check()
            except Exception as e:  # pylint: disable=broad-except
                logger.warning("Health check failed for AI provider %s: %s", name, e)
                health[f"ai_provider_{name}"] = False
        
        return health

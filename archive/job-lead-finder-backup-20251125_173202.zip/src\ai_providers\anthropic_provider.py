"""Anthropic provider implementation (requires anthropic package)."""

import json
import logging
from typing import List, Optional

from ..core.models import Job, JobEvaluation, Resume, JobSearchContext, RelevanceLevel
from .base import BaseAIProvider

logger = logging.getLogger(__name__)


class AnthropicProvider(BaseAIProvider):
    """AI provider using Anthropic Claude API."""

    def __init__(self, api_key: Optional[str] = None, model: str = "claude-3-sonnet-20240229"):
        """
        Initialize Anthropic provider.
        
        Args:
            api_key: Anthropic API key (uses ANTHROPIC_API_KEY env var if not provided)
            model: Model to use (default: claude-3-sonnet-20240229)
        """
        super().__init__(api_key, model)
        
        try:
            import anthropic
            self.client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
        except ImportError:
            raise ImportError(
                "Anthropic package not installed. Install with: pip install 'job-lead-finder[anthropic]'"
            )

    @property
    def provider_name(self) -> str:
        return "anthropic"

    async def evaluate_job_relevance(
        self,
        job: Job,
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> JobEvaluation:
        """Evaluate job relevance using Anthropic Claude."""
        prompt = self._create_evaluation_prompt(job, resume, context)
        
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=500,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            
            response_text = message.content[0].text
            parsed = await self._parse_evaluation_response(response_text)
            
            return JobEvaluation(
                job_id=job.id,
                ai_provider=self.provider_name,
                relevance_level=self._map_relevance_level(parsed.get("relevance_level", "unknown")),
                score=int(parsed.get("score", 50)),
                reasoning=parsed.get("reasoning", ""),
                match_details=parsed.get("match_details", {})
            )
        except Exception as e:
            logger.error("Anthropic evaluation error: %s", e)
            raise

    async def find_jobs(
        self,
        query: str,
        context: Optional[JobSearchContext] = None
    ) -> List[Job]:
        """Find jobs using Anthropic (simulated - would need job API integration)."""
        prompt = self._create_job_search_prompt(query, context)
        
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=2000,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            
            response_text = message.content[0].text
            jobs_data = json.loads(response_text)
            
            jobs = []
            for i, job_data in enumerate(jobs_data):
                job = Job(
                    id=f"anthropic_{i}",
                    title=job_data.get("title", ""),
                    company=job_data.get("company", ""),
                    location=job_data.get("location", ""),
                    description=job_data.get("description", ""),
                    url=job_data.get("url", ""),
                    source=self.provider_name,
                    job_type=job_data.get("job_type"),
                    salary_range=job_data.get("salary_range"),
                )
                jobs.append(job)
            
            return jobs
        except Exception as e:
            logger.error("Anthropic job search error: %s", e)
            return []

    async def batch_evaluate_jobs(
        self,
        jobs: List[Job],
        resume: Resume,
        context: Optional[JobSearchContext] = None
    ) -> List[JobEvaluation]:
        """Batch evaluate multiple jobs."""
        evaluations = []
        for job in jobs:
            try:
                evaluation = await self.evaluate_job_relevance(job, resume, context)
                evaluations.append(evaluation)
            except Exception as e:
                logger.error("Batch evaluation error for job %s: %s", job.id, e)
        return evaluations

    async def health_check(self) -> bool:
        """Check if Anthropic API is accessible."""
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=1,
                messages=[{"role": "user", "content": "test"}]
            )
            return message.content is not None
        except Exception as e:
            logger.warning("Anthropic health check failed: %s", e)
            return False

    async def get_usage_info(self) -> dict:
        """Get Anthropic API usage information."""
        try:
            return {
                "model": self.model,
                "status": "active",
            }
        except Exception as e:
            logger.warning("Could not retrieve usage info: %s", e)
            return {}

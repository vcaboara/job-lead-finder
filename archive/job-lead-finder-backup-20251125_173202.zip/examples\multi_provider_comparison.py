"""Example: Multi-Provider Comparison"""

import asyncio
import json
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.core.models import Resume, JobSearchContext
from src.orchestrator.job_finder import JobFinder
from src.ai_providers.mock import MockAIProvider
from src.job_sources.mock import MockJobSource
from src.evaluation.evaluators import MultiProviderEvaluator
from src.evaluation.comparator import SimpleEvaluationComparator


async def main():
    """Run multi-provider comparison example."""

    # Setup job finder
    job_finder = JobFinder()

    # Register job source
    job_finder.register_job_source(MockJobSource())

    # Register multiple AI providers
    provider1 = MockAIProvider()
    provider2 = MockAIProvider()
    
    job_finder.register_ai_provider(provider1)
    job_finder.register_ai_provider(provider2)

    # Register multi-provider evaluator
    job_finder.register_evaluator(
        "multi",
        MultiProviderEvaluator([provider1, provider2])
    )

    # Register comparator
    job_finder.comparator = SimpleEvaluationComparator()

    # Create resume
    resume = Resume(
        content="Tech professional with diverse experience",
        skills=["Python", "JavaScript", "Go", "AWS", "Kubernetes", "PostgreSQL"],
        experience="10 years of software engineering and DevOps",
        desired_roles=["Senior Engineer", "Staff Engineer", "Tech Lead"],
        desired_locations=["Remote", "San Francisco", "Austin"],
    )

    # Create search context
    context = JobSearchContext(
        resume=resume,
        search_query="Senior Software Engineer",
        preferred_sources=["mock_jobs"],
        ai_providers=["mock"],
    )

    # Find and evaluate jobs with provider comparison
    print("🔍 Searching for jobs with multi-provider evaluation...\n")
    result = await job_finder.find_and_evaluate_jobs(
        context=context,
        job_sources=["mock_jobs"],
        compare_providers=True,
    )

    print(f"📊 Found and evaluated {len(result.jobs)} jobs\n")

    # Display detailed results with comparisons
    for job in result.jobs:
        print(f"{'=' * 80}")
        print(f"📌 {job.title}")
        print(f"   Company: {job.company} | Location: {job.location}")
        print(f"   URL: {job.url}\n")

        # Show individual evaluations
        if job.id in result.evaluations:
            print("   📈 Individual Provider Evaluations:")
            for eval_obj in result.evaluations[job.id]:
                print(f"      [{eval_obj.ai_provider.upper()}]")
                print(f"        Relevance: {eval_obj.relevance_level.value}")
                print(f"        Score: {eval_obj.score}/100")
                print(f"        Reasoning: {eval_obj.reasoning}")

        # Show comparison if available
        if job.id in result.comparisons:
            comp = result.comparisons[job.id]
            print(f"\n   🔄 Consensus Analysis:")
            print(f"      Consensus Relevance: {comp.consensus_relevance.value}")
            print(f"      Consensus Score: {comp.consensus_score}/100")
            print(f"      Agreement Level: {int(comp.agreement_level * 100)}%")
            print(f"      Analysis: {comp.disagreement_analysis}")

        print()

    # Save detailed results
    output = {
        "search_query": context.search_query,
        "total_jobs": len(result.jobs),
        "jobs": [],
    }

    for job in result.jobs:
        job_entry = {
            "title": job.title,
            "company": job.company,
            "location": job.location,
            "individual_evaluations": [
                {
                    "provider": e.ai_provider,
                    "relevance": e.relevance_level.value,
                    "score": e.score,
                }
                for e in result.evaluations.get(job.id, [])
            ],
        }

        if job.id in result.comparisons:
            comp = result.comparisons[job.id]
            job_entry["consensus"] = {
                "relevance": comp.consensus_relevance.value,
                "score": comp.consensus_score,
                "agreement": f"{int(comp.agreement_level * 100)}%",
            }

        output["jobs"].append(job_entry)

    results_file = Path(__file__).parent / "multi_provider_results.json"
    results_file.write_text(json.dumps(output, indent=2))
    print(f"💾 Detailed results saved to {results_file}")


if __name__ == "__main__":
    asyncio.run(main())

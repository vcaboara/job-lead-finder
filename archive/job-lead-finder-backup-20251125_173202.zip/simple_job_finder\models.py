from dataclasses import dataclass, field
from typing import List, Dict, Any
from uuid import uuid4


@dataclass
class Job:
    id: str
    title: str
    company: str
    location: str
    description: str
    url: str
    source: str

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid4())


@dataclass
class Resume:
    content: str = ""
    skills: List[str] = field(default_factory=list)
    desired_roles: List[str] = field(default_factory=list)
    desired_locations: List[str] = field(default_factory=list)


@dataclass
class JobEvaluation:
    job_id: str
    provider: str
    score: int  # 0-100
    reasoning: str
    details: Dict[str, Any] = field(default_factory=dict)

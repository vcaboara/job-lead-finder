# AI-Powered Strategic Job Lead Finder

A modular, extensible job finder system that leverages AI to both discover job opportunities and evaluate their relevance to your professional profile. Designed for future UI integration and support for multiple AI providers.

## 🎯 Features

- **Modular Architecture**: Clean separation of concerns with pluggable components
- **Multiple AI Providers**: Support for various AI services (OpenAI, Anthropic, Gemini, etc.)
- **Multiple Job Sources**: Search across different job boards and platforms
- **AI-Driven Evaluation**: Uses AI to assess job relevance based on resume/profile
- **Multi-Provider Comparison**: Compare evaluations from multiple AI providers to reach consensus
- **Async-First Design**: Built for high-performance concurrent operations
- **Easy Extension**: Simple interfaces for adding new AI providers, job sources, and evaluators
- **CLI Interface**: Command-line tool for searching and evaluating jobs
- **UI-Ready**: Architected to support web/desktop UI in the future

## 📦 Project Structure

```
job-lead-finder/
├── src/
│   ├── core/                    # Core data models and abstractions
│   │   ├── models.py           # Data classes (Job, Resume, etc.)
│   │   ├── abstractions.py     # Abstract base classes
│   │   └── __init__.py
│   │
│   ├── ai_providers/            # AI provider implementations
│   │   ├── base.py             # Base provider with common logic
│   │   ├── mock.py             # Mock provider for testing
│   │   ├── openai_provider.py  # (Template for OpenAI integration)
│   │   ├── anthropic_provider.py # (Template for Anthropic integration)
│   │   └── __init__.py
│   │
│   ├── job_sources/             # Job board/source implementations
│   │   ├── mock.py             # Mock job source
│   │   ├── indeed.py           # (Template for Indeed)
│   │   ├── linkedin.py         # (Template for LinkedIn)
│   │   └── __init__.py
│   │
│   ├── evaluation/              # Job evaluation engines
│   │   ├── evaluators.py       # Single and multi-provider evaluators
│   │   ├── comparator.py       # Consensus and comparison logic
│   │   └── __init__.py
│   │
│   ├── orchestrator/            # Main job finder orchestrator
│   │   ├── job_finder.py       # Main JobFinder class
│   │   └── __init__.py
│   │
│   ├── cli/                     # Command-line interface
│   │   ├── cli.py              # Click CLI commands
│   │   └── __init__.py
│   │
│   └── __init__.py
│
├── examples/
│   ├── basic_search.py         # Basic search example
│   └── (future UI examples)
│
├── tests/
│   ├── test_ai_providers.py    # AI provider tests
│   ├── test_evaluators.py      # Evaluator tests
│   └── (more tests)
│
├── config/
│   ├── settings.py             # Configuration management
│   └── .env.example            # Environment variables template
│
├── pyproject.toml              # Project configuration and dependencies
├── README.md                   # This file
└── ARCHITECTURE.md             # Detailed architecture documentation
```

## 🚀 Quick Start

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd job-lead-finder
```

2. Install the package in development mode:
```bash
pip install -e ".[dev]"
```

### Basic Usage

#### Command-Line Interface

```bash
# Search for jobs
job-finder search --query "Python Developer" \
  --skills Python Docker AWS \
  --roles "Software Engineer" "Backend Engineer" \
  --locations Remote "San Francisco"

# Search with AI provider comparison
job-finder search --query "DevOps Engineer" --compare

# Save results to file
job-finder search --query "Senior Engineer" --output results.json

# Check health of services
job-finder health
```

#### Python API

```python
import asyncio
from src.core.models import Resume, JobSearchContext
from src.orchestrator.job_finder import JobFinder
from src.ai_providers.mock import MockAIProvider
from src.job_sources.mock import MockJobSource
from src.evaluation.evaluators import AIProviderEvaluator

async def main():
    # Setup
    job_finder = JobFinder()
    job_finder.register_job_source(MockJobSource())
    mock_ai = MockAIProvider()
    job_finder.register_ai_provider(mock_ai)
    job_finder.register_evaluator("mock", AIProviderEvaluator(mock_ai))

    # Create profile
    resume = Resume(
        skills=["Python", "Docker", "Kubernetes"],
        desired_roles=["Senior Engineer"],
        desired_locations=["Remote"],
    )

    # Search context
    context = JobSearchContext(
        resume=resume,
        search_query="Senior Python Developer",
    )

    # Find and evaluate
    result = await job_finder.find_and_evaluate_jobs(context)

    # Process results
    for job in result.jobs:
        print(f"{job.title} at {job.company}")
        for eval in result.evaluations.get(job.id, []):
            print(f"  Relevance: {eval.relevance_level.value} ({eval.score}/100)")

asyncio.run(main())
```

## 🔧 Core Concepts

### Data Models

- **Job**: Represents a job listing from any source
- **Resume**: User's profile with skills, experience, and preferences
- **JobSearchContext**: Context for a search session
- **JobEvaluation**: AI provider's evaluation of a job's relevance
- **EvaluationComparison**: Consensus from multiple providers
- **JobFinderResult**: Complete result of find + evaluate operation

### Components

#### AI Providers (Abstract: `AIProvider`)
- Responsible for evaluating job relevance and finding jobs
- Can be implemented for OpenAI, Anthropic, Gemini, or any AI service
- Current implementations: `MockAIProvider`

#### Job Sources (Abstract: `JobSource`)
- Responsible for searching and fetching jobs from platforms
- Can be implemented for LinkedIn, Indeed, Glassdoor, custom APIs
- Current implementations: `MockJobSource`

#### Evaluators (Abstract: `JobEvaluator`)
- Use AI providers to evaluate job relevance
- `AIProviderEvaluator`: Uses a single provider
- `MultiProviderEvaluator`: Uses multiple providers

#### Comparators (Abstract: `EvaluationComparator`)
- Compare evaluations from multiple AI providers
- Compute consensus relevance, agreement level, etc.
- Current implementation: `SimpleEvaluationComparator`

#### Job Finder (Orchestrator)
- Coordinates all components
- Workflow: Find jobs → Evaluate → Compare → Return results
- Manages component lifecycle and error handling

## 🔌 Extending the System

### Adding a New AI Provider

Create `src/ai_providers/my_provider.py`:

```python
from src.ai_providers.base import BaseAIProvider
from src.core.models import Job, JobEvaluation, Resume, JobSearchContext

class MyAIProvider(BaseAIProvider):
    @property
    def provider_name(self) -> str:
        return "my_provider"

    async def evaluate_job_relevance(
        self, 
        job: Job, 
        resume: Resume, 
        context=None
    ) -> JobEvaluation:
        # Implement evaluation logic
        prompt = self._create_evaluation_prompt(job, resume, context)
        # Call your AI API
        response = await my_ai_api(prompt)
        # Parse and return
        ...

    async def find_jobs(self, query: str, context=None):
        # Implement job finding
        ...

    async def batch_evaluate_jobs(self, jobs, resume, context=None):
        # Implement batch evaluation
        ...
```

### Adding a New Job Source

Create `src/job_sources/my_source.py`:

```python
from src.core.abstractions import JobSource
from src.core.models import Job

class MyJobSource(JobSource):
    @property
    def source_name(self) -> str:
        return "my_source"

    async def search_jobs(self, query: str, filters=None):
        # Search for jobs
        # Return List[Job]
        ...

    async def get_job_details(self, job_id: str):
        # Get detailed job info
        # Return Job or None
        ...
```

### Using with Your UI

```python
# In your UI backend
from src.orchestrator.job_finder import JobFinder

job_finder = JobFinder()

# Register components
job_finder.register_job_source(LinkedInSource())
job_finder.register_ai_provider(OpenAIProvider())
job_finder.register_evaluator("openai", AIProviderEvaluator(OpenAIProvider()))

# Expose via API endpoints
async def search_endpoint(query: str, skills: list[str]):
    context = JobSearchContext(
        resume=build_from_user_profile(),
        search_query=query,
    )
    result = await job_finder.find_and_evaluate_jobs(context)
    return result  # Return as JSON
```

## 📊 Comparison Example

When using multiple AI providers:

```python
result = await job_finder.find_and_evaluate_jobs(
    context,
    compare_providers=True  # Enable multi-provider comparison
)

for job_id, comparison in result.comparisons.items():
    print(f"Job: {comparison.job_id}")
    print(f"Consensus: {comparison.consensus_relevance.value} ({comparison.consensus_score}/100)")
    print(f"Agreement: {int(comparison.agreement_level * 100)}%")
    print(f"Analysis: {comparison.disagreement_analysis}")
```

## 🧪 Testing

Run tests with pytest:

```bash
pytest tests/ -v

# Run specific test file
pytest tests/test_evaluators.py -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html
```

Example test:

```python
import pytest
from src.ai_providers.mock import MockAIProvider
from src.core.models import Job, Resume

@pytest.mark.asyncio
async def test_mock_evaluation():
    provider = MockAIProvider()
    job = Job(
        id="test_1",
        title="Python Developer",
        company="Test Corp",
        location="Remote",
        description="Looking for Python developer",
        url="http://example.com",
        source="test"
    )
    resume = Resume(skills=["Python", "Docker"])
    
    evaluation = await provider.evaluate_job_relevance(job, resume)
    assert evaluation.score >= 0
    assert evaluation.score <= 100
```

## 🔐 Configuration

Environment variables (create `.env`):

```env
# OpenAI (for OpenAI provider)
OPENAI_API_KEY=sk-...

# Anthropic (for Anthropic provider)
ANTHROPIC_API_KEY=sk-ant-...

# Google (for Gemini provider)
GOOGLE_API_KEY=...

# LinkedIn (if implementing LinkedIn source)
LINKEDIN_API_KEY=...
```

## 📚 Future Enhancements

- [ ] OpenAI provider implementation
- [ ] Anthropic provider implementation
- [ ] Google Gemini provider implementation
- [ ] LinkedIn integration
- [ ] Indeed integration
- [ ] Glassdoor integration
- [ ] Web UI (React)
- [ ] Desktop UI (Electron/Tauri)
- [ ] Database persistence (PostgreSQL/MongoDB)
- [ ] Job cache and deduplication
- [ ] Advanced filtering and sorting
- [ ] Job notifications and alerts
- [ ] Resume optimization recommendations
- [ ] Interview prep suggestions
- [ ] Salary negotiation insights

## 🤝 Contributing

1. Create a feature branch
2. Implement your changes
3. Add tests
4. Submit a pull request

## 📄 License

MIT

## 📞 Support

For issues and questions, please open an issue on GitHub.

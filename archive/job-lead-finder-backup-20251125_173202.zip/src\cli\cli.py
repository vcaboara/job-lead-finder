"""Command-line interface for the job finder."""

import asyncio
import json
import logging
from pathlib import Path
from typing import Optional

import click

from ..core.models import Resume, JobSearchContext
from ..orchestrator.job_finder import JobFinder
from ..ai_providers.mock import MockAIProvider
from ..job_sources.mock import MockJobSource
from ..evaluation.evaluators import AIProviderEvaluator, MultiProviderEvaluator
from ..evaluation.comparator import SimpleEvaluationComparator

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class JobFinderCLI:
    """Command-line interface for the job finder."""

    def __init__(self):
        """Initialize the CLI with default components."""
        self.job_finder = JobFinder()
        self._setup_default_providers()

    def _setup_default_providers(self):
        """Setup default mock providers for demonstration."""
        # Register job sources
        self.job_finder.register_job_source(MockJobSource())

        # Register AI providers
        self.job_finder.register_ai_provider(MockAIProvider())

        # Register evaluators
        mock_provider = MockAIProvider()
        self.job_finder.register_evaluator("mock_eval", AIProviderEvaluator(mock_provider))
        self.job_finder.register_evaluator(
            "multi_eval",
            MultiProviderEvaluator([mock_provider])
        )

        # Register comparator
        self.job_finder.comparator = SimpleEvaluationComparator()

    async def search_jobs(
        self,
        query: str,
        skills: Optional[list[str]] = None,
        desired_roles: Optional[list[str]] = None,
        desired_locations: Optional[list[str]] = None,
        compare_providers: bool = False,
        evaluator: Optional[str] = None,
    ):
        """Search for jobs and evaluate their relevance."""
        # Create resume from inputs
        resume = Resume(
            content="Sample resume content",
            skills=skills or ["Python", "JavaScript", "Docker"],
            desired_roles=desired_roles or ["Software Engineer", "DevOps Engineer"],
            desired_locations=desired_locations or ["Remote", "San Francisco", "New York"],
        )

        # Create search context
        context = JobSearchContext(
            resume=resume,
            search_query=query,
            preferred_sources=["mock_jobs"],
            ai_providers=["mock"],
            filters={},
        )

        # Find and evaluate jobs
        logger.info("Starting job search for: %s", query)
        result = await self.job_finder.find_and_evaluate_jobs(
            context=context,
            evaluator_name=evaluator,
            compare_providers=compare_providers,
        )

        return result

    def format_results(self, result):
        """Format and display results."""
        output = {
            "total_jobs_found": len(result.jobs),
            "jobs_evaluated": len(result.evaluations),
            "comparisons_done": len(result.comparisons),
            "errors": result.errors,
            "jobs": [],
        }

        for job in result.jobs:
            job_data = {
                "id": job.id,
                "title": job.title,
                "company": job.company,
                "location": job.location,
                "job_type": job.job_type,
                "salary_range": job.salary_range,
                "url": job.url,
            }

            # Add evaluations if available
            if job.id in result.evaluations:
                job_data["evaluations"] = []
                for eval_obj in result.evaluations[job.id]:
                    job_data["evaluations"].append({
                        "ai_provider": eval_obj.ai_provider,
                        "relevance_level": eval_obj.relevance_level.value,
                        "score": eval_obj.score,
                        "reasoning": eval_obj.reasoning,
                        "match_details": eval_obj.match_details,
                    })

            # Add comparison if available
            if job.id in result.comparisons:
                comp = result.comparisons[job.id]
                job_data["comparison"] = {
                    "consensus_relevance": comp.consensus_relevance.value,
                    "consensus_score": comp.consensus_score,
                    "agreement_level": f"{int(comp.agreement_level * 100)}%",
                    "disagreement_analysis": comp.disagreement_analysis,
                }

            output["jobs"].append(job_data)

        return output


@click.group()
def cli():
    """Job Lead Finder CLI."""
    pass


@cli.command()
@click.option("--query", "-q", required=True, help="Job search query")
@click.option("--skills", "-s", multiple=True, help="Skills to search for")
@click.option("--roles", "-r", multiple=True, help="Desired job roles")
@click.option("--locations", "-l", multiple=True, help="Desired locations")
@click.option("--compare", is_flag=True, help="Compare results from multiple AI providers")
@click.option("--output", "-o", help="Output file (JSON)")
def search(query, skills, roles, locations, compare, output):
    """Search for jobs and evaluate relevance."""
    cli_instance = JobFinderCLI()

    # Run async search
    result = asyncio.run(
        cli_instance.search_jobs(
            query=query,
            skills=list(skills) if skills else None,
            desired_roles=list(roles) if roles else None,
            desired_locations=list(locations) if locations else None,
            compare_providers=compare,
        )
    )

    # Format and display results
    formatted = cli_instance.format_results(result)
    formatted_json = json.dumps(formatted, indent=2)

    if output:
        Path(output).write_text(formatted_json)
        click.echo(f"Results saved to {output}")
    else:
        click.echo(formatted_json)


@cli.command()
def health():
    """Check health of all services."""
    cli_instance = JobFinderCLI()
    health_status = asyncio.run(cli_instance.job_finder.health_check())

    output = {"health_check": health_status}
    click.echo(json.dumps(output, indent=2))


if __name__ == "__main__":
    cli()

from typing import List
from .models import Job, Resume, JobEvaluation


class MockAIProvider:
    """Simple deterministic mock provider for quick testing."""

    def __init__(self, name: str = "mock"):
        self.name = name

    def evaluate(self, job: Job, resume: Resume) -> JobEvaluation:
        # score is percent of resume skills mentioned in job description
        desc = job.description.lower()
        matches = sum(1 for s in resume.skills if s.lower() in desc)
        total = max(len(resume.skills), 1)
        score = int((matches / total) * 100)
        # bias small amount by presence in title
        if any(role.lower() in job.title.lower() for role in resume.desired_roles):
            score = min(100, score + 10)

        reasoning = f"{matches} skill matches of {total}; title match: {any(role.lower() in job.title.lower() for role in resume.desired_roles)}"
        return JobEvaluation(job_id=job.id, provider=self.name, score=score, reasoning=reasoning, details={"matches": matches})

    def find_jobs(self, query: str) -> List[Job]:
        # Providers can also simulate search if desired; keep simple and return empty
        return []


class GeminiProviderTemplate:
    """Template for Google Gemini provider.

    To enable real Gemini calls, install `google-generativeai` and set `GOOGLE_API_KEY`.
    This class is a minimal template showing where to plug calls; it intentionally
    does not import the Gemini package so this simplified package stays dependency-free.
    """

    def __init__(self, name: str = "gemini"):
        self.name = name

    def evaluate(self, job: Job, resume: Resume) -> JobEvaluation:
        # Placeholder implementation — replace with real API calls later
        reasoning = "Gemini evaluation not configured; use GeminiProvider for real calls."
        return JobEvaluation(job_id=job.id, provider=self.name, score=50, reasoning=reasoning)

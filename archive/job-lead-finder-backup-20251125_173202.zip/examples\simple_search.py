"""Example that runs the simplified implementation."""
import sys
from simple_job_finder.main import main

if __name__ == "__main__":
    # Example arguments - change as needed
    sys.argv[1:] = ["search", "--query", "DevOps Engineer", "--skills", "Python", "Docker", "--roles", "DevOps"]
    main()

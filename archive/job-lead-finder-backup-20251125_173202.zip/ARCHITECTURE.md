# Architecture Documentation

## System Overview

The Job Lead Finder is built on a modular, extensible architecture that separates concerns into distinct layers:

```
┌─────────────────────────────────────────────────────────────────┐
│                     User Interface Layer                         │
│  (CLI, Web UI, Desktop UI - Future implementations)              │
└────────────────────────┬────────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────────┐
│                    Orchestrator Layer                            │
│  JobFinder: Coordinates job finding and evaluation workflow      │
└────────────────────────┬────────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
┌───────▼─────────┐ ┌───▼──────────────┐ ┌──▼─────────────────┐
│  Job Sources    │ │ Evaluation Layer │ │ Comparators        │
│  - MockSource   │ │                  │ │ - Simple           │
│  - LinkedIn     │ │ - Evaluators     │ │   Comparator      │
│  - Indeed       │ │ - Multi-Provider │ │                    │
│  - Custom APIs  │ │   Logic          │ └────────────────────┘
└────────┬────────┘ └────────┬─────────┘
         │                    │
         │    ┌───────────────┤
         │    │               │
    ┌────▼────▼────┐ ┌──────▼─────────────┐
    │  Job         │ │  AI Providers      │
    │  Model       │ │  - OpenAI          │
    │              │ │  - Anthropic       │
    │  Resume      │ │  - Gemini          │
    │  Model       │ │  - Mock            │
    │              │ │  - Custom          │
    │  Context     │ └────────────────────┘
    │  Models      │
    │              │
    │  Results     │
    │  Models      │
    └──────────────┘
```

## Core Components

### 1. Core Models (`src/core/models.py`)

**Data Classes:**
- `Job`: Represents a job listing
- `Resume`: User profile with skills and preferences
- `JobSearchContext`: Search session context
- `JobEvaluation`: AI evaluation of a job
- `EvaluationComparison`: Multi-provider consensus
- `JobFinderResult`: Complete result of an operation

**Enums:**
- `RelevanceLevel`: HIGHLY_RELEVANT, RELEVANT, SOMEWHAT_RELEVANT, NOT_RELEVANT, UNKNOWN

### 2. Abstractions (`src/core/abstractions.py`)

**Abstract Base Classes:**

#### `AIProvider`
Defines the interface for AI-based job evaluation and finding.

```python
class AIProvider(ABC):
    @abstractmethod
    async def evaluate_job_relevance(job, resume, context) -> JobEvaluation
    
    @abstractmethod
    async def find_jobs(query, context) -> List[Job]
    
    @abstractmethod
    async def batch_evaluate_jobs(jobs, resume, context) -> List[JobEvaluation]
```

#### `JobSource`
Defines the interface for job search platforms.

```python
class JobSource(ABC):
    @abstractmethod
    async def search_jobs(query, filters) -> List[Job]
    
    @abstractmethod
    async def get_job_details(job_id) -> Optional[Job]
```

#### `JobEvaluator`
Defines the interface for job evaluation engines.

```python
class JobEvaluator(ABC):
    @abstractmethod
    async def evaluate(job, resume, context) -> JobEvaluation
    
    @abstractmethod
    async def batch_evaluate(jobs, resume, context) -> List[JobEvaluation]
```

#### `EvaluationComparator`
Defines the interface for comparing multiple evaluations.

```python
class EvaluationComparator(ABC):
    @abstractmethod
    async def compare_evaluations(evaluations: Dict[str, JobEvaluation]) -> EvaluationComparison
```

### 3. AI Providers (`src/ai_providers/`)

**Base Implementation:**
- `BaseAIProvider`: Common functionality for all providers
  - Prompt generation
  - Response parsing
  - Relevance level mapping

**Implementations:**
- `MockAIProvider`: For testing and demonstration
- `OpenAIProvider`: Uses OpenAI GPT models
- `AnthropicProvider`: Uses Anthropic Claude models
- (Future) `GeminiProvider`: Uses Google Gemini models
- (Future) Custom providers for enterprise solutions

### 4. Job Sources (`src/job_sources/`)

**Implementations:**
- `MockJobSource`: Simulated job data for testing
- (Future) `LinkedInSource`: LinkedIn job API
- (Future) `IndeedSource`: Indeed API
- (Future) `GlassdoorSource`: Glassdoor integration
- (Future) `CustomAPISource`: Generic job API wrapper

### 5. Evaluation Layer (`src/evaluation/`)

**Components:**

#### `AIProviderEvaluator`
Wraps a single AI provider for evaluation.

```python
evaluator = AIProviderEvaluator(openai_provider)
evaluation = await evaluator.evaluate(job, resume, context)
```

#### `MultiProviderEvaluator`
Evaluates with multiple providers for consensus.

```python
evaluator = MultiProviderEvaluator([openai_provider, anthropic_provider])
evaluations = await evaluator.batch_evaluate(jobs, resume, context)
```

#### `SimpleEvaluationComparator`
Computes consensus from multiple evaluations.

```python
comparator = SimpleEvaluationComparator()
comparison = await comparator.compare_evaluations({
    "openai": eval1,
    "anthropic": eval2
})
```

### 6. Orchestrator (`src/orchestrator/job_finder.py`)

**Main Class: `JobFinder`**

Coordinates all components in a workflow:

```
1. Register components (sources, providers, evaluators)
2. Find jobs via job sources
3. Evaluate jobs via AI providers
4. Compare evaluations across providers
5. Return consolidated results
```

**Key Methods:**
- `find_jobs()`: Search for jobs
- `evaluate_jobs()`: Evaluate job relevance
- `compare_evaluations()`: Compare multi-provider evaluations
- `find_and_evaluate_jobs()`: Complete workflow
- `health_check()`: Verify all components

### 7. CLI Interface (`src/cli/cli.py`)

Built with Click framework.

**Commands:**
- `search`: Search and evaluate jobs
- `health`: Check service health

## Data Flow Diagrams

### Single Provider Evaluation Flow

```
User Input (query, resume, preferences)
    ↓
JobSearchContext
    ↓
JobFinder.find_jobs()
    ↓
[Job Sources] → List[Job]
    ↓
JobFinder.evaluate_jobs()
    ↓
[AI Provider] → List[JobEvaluation]
    ↓
JobFinderResult {
    jobs: List[Job],
    evaluations: Dict[job_id → evaluations],
    comparisons: {},  // empty
    errors: []
}
```

### Multi-Provider Comparison Flow

```
User Input (query, resume, preferences)
    ↓
JobSearchContext (compare_providers=True)
    ↓
JobFinder.find_jobs()
    ↓
[Job Sources] → List[Job]
    ↓
JobFinder.evaluate_jobs(all_providers=True)
    ↓
[AI Provider 1] → JobEvaluation[]
[AI Provider 2] → JobEvaluation[]
[AI Provider N] → JobEvaluation[]
    ↓
JobFinder.compare_evaluations()
    ↓
[Comparator] → Consensus for each job
    ↓
JobFinderResult {
    jobs: List[Job],
    evaluations: Dict[job_id → [eval1, eval2, ...]],
    comparisons: Dict[job_id → EvaluationComparison],
    errors: []
}
```

## Extension Points

### Adding a New AI Provider

1. Create new class in `src/ai_providers/`
2. Inherit from `BaseAIProvider`
3. Implement required methods:
   - `provider_name` property
   - `evaluate_job_relevance()`
   - `find_jobs()`
   - `batch_evaluate_jobs()`
4. Register with `JobFinder`:
   ```python
   job_finder.register_ai_provider(MyProvider())
   ```

### Adding a New Job Source

1. Create new class in `src/job_sources/`
2. Inherit from `JobSource`
3. Implement required methods:
   - `source_name` property
   - `search_jobs()`
   - `get_job_details()`
4. Register with `JobFinder`:
   ```python
   job_finder.register_job_source(MyJobSource())
   ```

### Adding a New Evaluator

1. Create new class in `src/evaluation/`
2. Inherit from `JobEvaluator`
3. Implement required methods:
   - `evaluate()`
   - `batch_evaluate()`
4. Register with `JobFinder`:
   ```python
   job_finder.register_evaluator("my_eval", MyEvaluator())
   ```

### Customizing Comparators

1. Create new class in `src/evaluation/`
2. Inherit from `EvaluationComparator`
3. Implement `compare_evaluations()`
4. Set as `JobFinder.comparator`:
   ```python
   job_finder.comparator = MyComparator()
   ```

## Configuration Management

**Environment Variables:**
```
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...
DEBUG=True/False
LOG_LEVEL=INFO/DEBUG/WARNING/ERROR
```

**Configuration Class:**
```python
from config.settings import AppConfig

config = AppConfig.from_env()
# or
config = AppConfig.from_file("config.yaml")
```

## Error Handling

The system uses async/await with try-catch blocks:

```python
try:
    result = await job_finder.find_and_evaluate_jobs(context)
except SpecificError as e:
    logger.error("Specific error: %s", e)
except Exception as e:
    logger.error("General error: %s", e)
    result.errors.append(str(e))
```

Errors are collected in `JobFinderResult.errors` for graceful degradation.

## Performance Considerations

### Async Operations
- All I/O operations are async
- Allows concurrent job searches and evaluations
- Use `asyncio.gather()` for parallel operations

### Batch Evaluation
- `batch_evaluate_jobs()` processes multiple jobs together
- Reduces API calls and improves throughput
- Adjustable batch sizes based on rate limits

### Caching
- Future: Cache job listings to reduce duplicate searches
- Future: Cache evaluations to avoid re-evaluating unchanged jobs
- Future: LRU cache for frequently accessed jobs

## Testing Strategy

### Unit Tests
```python
# Test AI providers
test_ai_provider_evaluate()
test_ai_provider_find_jobs()

# Test evaluators
test_single_evaluator()
test_multi_provider_evaluator()

# Test comparators
test_evaluation_comparison()
```

### Integration Tests
```python
# Test complete workflow
test_find_and_evaluate_jobs()

# Test error handling
test_provider_failure_handling()
test_source_failure_handling()
```

### Mock Data
- `MockAIProvider`: Realistic but deterministic evaluations
- `MockJobSource`: Predefined job listings
- Enables full testing without external APIs

## Future Enhancements

### Short Term
- [ ] Add OpenAI integration (full, not template)
- [ ] Add Anthropic integration (full, not template)
- [ ] Add LinkedIn job source integration
- [ ] Basic web UI (FastAPI + React)
- [ ] Database persistence
- [ ] Job caching and deduplication

### Medium Term
- [ ] Desktop UI (Electron/Tauri)
- [ ] Indeed and Glassdoor integration
- [ ] Advanced filtering and sorting
- [ ] Job notifications and alerts
- [ ] Performance optimizations
- [ ] Rate limiting and throttling

### Long Term
- [ ] Machine learning model for job ranking
- [ ] Resume optimization engine
- [ ] Interview preparation suggestions
- [ ] Salary negotiation insights
- [ ] Career path recommendations
- [ ] Multi-language support
- [ ] Mobile app

## Security Considerations

1. **API Keys**: Use environment variables, never hardcode
2. **Rate Limiting**: Implement per-provider limits
3. **Authentication**: Support OAuth2 for job board APIs
4. **Data Privacy**: Don't store sensitive resume data
5. **Input Validation**: Sanitize all user inputs
6. **Output Escaping**: Prevent injection attacks

## Deployment

### Development
```bash
pip install -e ".[dev]"
python examples/basic_search.py
```

### Production
```bash
pip install .
job-finder search --query "Senior Engineer"
```

### Docker
```dockerfile
FROM python:3.10
COPY . /app
WORKDIR /app
RUN pip install .
CMD ["job-finder", "search"]
```

## Logging and Monitoring

- Configured via `logging` module
- Different log levels for development/production
- Structured logging for monitoring tools (ELK, Datadog, etc.)
- Performance metrics for each component

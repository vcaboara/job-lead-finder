"""Mock job source for testing."""

from typing import Any, Dict, List, Optional

from ..core.abstractions import JobSource
from ..core.models import Job


class MockJobSource(JobSource):
    """Mock job source for testing without API calls."""

    @property
    def source_name(self) -> str:
        return "mock_jobs"

    async def search_jobs(
        self,
        query: str,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[Job]:
        """Generate mock job listings."""
        jobs = []
        
        mock_data = [
            {
                "title": "Senior Python Developer",
                "company": "TechCorp Inc",
                "location": "San Francisco, CA",
                "description": "We're looking for a Senior Python Developer with 5+ years of experience. Required: Python, Django, PostgreSQL. Nice to have: Docker, Kubernetes.",
                "url": "https://example.com/jobs/1",
                "job_type": "full-time",
                "salary_range": "$120k - $160k",
            },
            {
                "title": "Full Stack Engineer",
                "company": "DataSoft Solutions",
                "location": "New York, NY",
                "description": "Full Stack Engineer needed for growing startup. Skills required: React, Node.js, MongoDB. Must have startup experience.",
                "url": "https://example.com/jobs/2",
                "job_type": "full-time",
                "salary_range": "$100k - $140k",
            },
            {
                "title": "DevOps Engineer",
                "company": "CloudServices Ltd",
                "location": "Remote",
                "description": "DevOps Engineer to manage our cloud infrastructure. Required: Kubernetes, AWS, CI/CD pipelines, Infrastructure as Code.",
                "url": "https://example.com/jobs/3",
                "job_type": "full-time",
                "salary_range": "$110k - $150k",
            },
            {
                "title": "ML Engineer - AI Team",
                "company": "AI Systems Corp",
                "location": "Austin, TX",
                "description": "Machine Learning Engineer for AI/ML team. Required: Python, TensorFlow, PyTorch, experience with large language models.",
                "url": "https://example.com/jobs/4",
                "job_type": "full-time",
                "salary_range": "$130k - $180k",
            },
            {
                "title": "Junior Backend Developer",
                "company": "StartupXYZ",
                "location": "Remote",
                "description": "Junior Backend Developer to join our growing team. Required: JavaScript/TypeScript, Node.js. Strong fundamentals in computer science.",
                "url": "https://example.com/jobs/5",
                "job_type": "full-time",
                "salary_range": "$70k - $90k",
            },
        ]
        
        for i, job_data in enumerate(mock_data):
            job = Job(
                id=f"mock_job_{i}",
                title=job_data["title"],
                company=job_data["company"],
                location=job_data["location"],
                description=job_data["description"],
                url=job_data["url"],
                source=self.source_name,
                job_type=job_data["job_type"],
                salary_range=job_data["salary_range"]
            )
            jobs.append(job)
        
        return jobs

    async def get_job_details(self, job_id: str) -> Optional[Job]:
        """Get details for a specific job."""
        jobs = await self.search_jobs("")
        for job in jobs:
            if job.id == job_id:
                return job
        return None
